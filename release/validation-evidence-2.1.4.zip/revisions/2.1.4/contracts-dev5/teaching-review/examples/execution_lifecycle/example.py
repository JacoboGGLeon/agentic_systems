import asyncio
import agentic_systems as toolkit
import pydantic

class State(pydantic.BaseModel):
    value: int

@toolkit.tool
def increment(value: int) -> dict:
    return {'value': value + 1}

@toolkit.tool
def double(value: int) -> dict:
    return {'value': value * 2}


def run():
    graph = toolkit.StateGraph(State)
    graph.add_node('increase', increment)
    graph.add_node('double', double)
    graph.add_edge(toolkit.START, 'increase')
    graph.add_edge('increase', 'double')
    graph.add_edge('double', toolkit.END)
    unit = toolkit.Agent('lifecycle', graph=graph)
    prepared = unit.compile()
    direct = unit.run({"value": 3}, limits=toolkit.Limits(max_actions=2))
    asynchronous = asyncio.run(prepared.arun({"value": 3}))
    limited = unit.run({"value": 3}, limits=toolkit.Limits(max_actions=1))
    assert direct.ok and direct.data == asynchronous.data == {"value": 8}
    assert not limited.ok
    return {
        "input": {"value": 3},
        "process": prepared.inspect(),
        "output": direct.to_dict(),
        "limit_failure": limited.to_dict(),
    }
