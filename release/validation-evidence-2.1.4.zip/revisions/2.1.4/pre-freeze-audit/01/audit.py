"""Read-only product audit: historical AWS behavior and current closure gaps."""

import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[4]
DEST = Path(__file__).resolve().parent
paths = (
    "src/agentic_systems/utils.py",
    "src/agentic_systems/providers/bedrock_runtime.py",
    "src/agentic_systems/providers/bedrock/identity.py",
    "src/agentic_systems/integrations/adapters/strands.py",
    "pyproject.toml",
)
historical = []
for tag in ("v2.1.0", "v2.1.1", "v2.1.2"):
    row = {"tag": tag, "files": {}}
    for path in paths:
        source = subprocess.check_output(["git", "show", f"{tag}:{path}"], cwd=ROOT, encoding="utf-8")
        item = {"sha256": hashlib.sha256(source.encode()).hexdigest()}
        if path.endswith(".py"):
            tree = ast.parse(source)
            if path.endswith("utils.py"):
                item["aws_functions"] = [node.name for node in tree.body if isinstance(node, ast.FunctionDef)
                                         and any(word in node.name for word in ("aws", "boto3", "ada"))]
            if path.endswith("bedrock_runtime.py"):
                item["session_statements"] = [line.strip() for line in source.splitlines() if "session" in line]
            if path.endswith("strands.py"):
                item["passes_canonical_session_to_strands"] = '"boto_session": session' in source
                model = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "_materialize_model")
                assignments = [node for node in model.body[0].body if isinstance(node, ast.Assign)
                               and any(isinstance(target, ast.Name) and target.id in {"runtime", "session", "auth_mode", "region_name", "model_kwargs"} for target in node.targets)]
                item["session_assignments"] = [ast.unparse(node) for node in assignments]
        else:
            item["has_ada_extra"] = any(line.strip().startswith("ada =") for line in source.splitlines())
        row["files"][path] = item
    historical.append(row)

configuration_path = ROOT / "src/agentic_systems/_configuration.py"
tree = ast.parse(configuration_path.read_text(encoding="utf-8"))
runtime = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "runtime")
runtime_parameters = [arg.arg for arg in (*runtime.args.args, *runtime.args.kwonlyargs)]
junit = ET.parse(ROOT / "revisions/2.1.4/grammar-dev7/offline-junit.xml").getroot()
test_groups = Counter(".".join(test.get("classname", "").split(".")[:2]) for test in junit.iter("testcase"))
quality = (ROOT / ".github/workflows/quality.yml").read_text(encoding="utf-8")
report = {
    "date_local": "2026-10-29", "version": "2.1.4.dev7", "sdk_changed_by_this_audit": False,
    "historical_aws": historical,
    "current_runtime_parameters": runtime_parameters,
    "public_session_injection_available": "session" in runtime_parameters,
    "default_collection_log": "default-collection.txt",
    "baseline_dev7_junit_groups": dict(test_groups),
    "quality_workflow": {
        "installs_213_wheel": "agentic_systems-2.1.3-py3-none-any.whl" in quality,
        "expects_213_version": "EXPECTED_VERSION: '2.1.3'" in quality,
        "references_absent_catalog_tool": "examples/catalog_tools.py" in quality and not (ROOT / "examples/catalog_tools.py").exists(),
    },
    "proposed_ada_delivery": "independent optional package; not implemented or published",
    "inference_calls": 0,
}
(DEST / "findings.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: report[key] for key in ("public_session_injection_available", "baseline_dev7_junit_groups", "quality_workflow")}, indent=2))
