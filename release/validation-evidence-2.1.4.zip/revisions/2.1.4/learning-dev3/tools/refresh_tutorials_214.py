"""Build the maintained dev3 learning notebooks from explicit, visible examples."""
from pathlib import Path
import json
import textwrap
import nbformat
ROOT=Path(__file__).resolve().parents[1]
V="2.1.4.dev3"
N=nbformat.v4
IMPORTS="""from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
import agentic_systems as toolkit
assert toolkit.__version__ == '2.1.4.dev3'
"""
ROOT_SETUP="""from pathlib import Path
import sys
ROOT = next(p for p in (Path.cwd(), *Path.cwd().parents) if (p / 'examples/common_graph/application.py').is_file())
sys.path.insert(0, str(ROOT))
"""
def code(s,tags=()):return N.new_code_cell(textwrap.dedent(s).strip()+"\n",metadata={"tags":list(tags)})
def md(s):return N.new_markdown_cell(s)
def save(path,title,description,cells):
    path=ROOT/path;path.parent.mkdir(parents=True,exist_ok=True)
    nb=N.new_notebook(cells=[md('# '+title+' · '+V+'\n\n'+description),*cells],metadata={"kernelspec":{"name":"python3","display_name":"Python 3","language":"python"},"agentic_systems":{"version":V,"orchestration":"langgraph"}})
    nbformat.validate(nb);nbformat.write(nb,path)

def lesson(path,title,description,sources):
    save(path,title,description,[code(IMPORTS),*[code(s) if isinstance(s,str) else s for s in sources]])

BASE="""class State(TypedDict, total=False):
    value:int
@toolkit.tool
def increment(value:int)->dict:
    return {'value':value+1}
graph=StateGraph(State)
graph.add_node('increment',increment)
graph.add_edge(START,'increment')
graph.add_edge('increment',END)
agent=toolkit.Agent('counter',graph=graph)
"""
lesson('tutorials/core/00_start.ipynb','Tu primer Agent','Input value=3 → Tool determinista dentro de un StateGraph → value=4. Requiere solamente el SDK instalado.',[BASE,"result=agent.run({'value':3})\nassert result.ok and result.data == {'value':4}\nprint(result.data)"])
lesson('tutorials/core/01_tools_skills.ipynb','Tools y Skills','Una Tool opera; una Skill declara capacidades e instrucciones. El grafo decide qué se ejecuta. load_skill necesita los recursos locales enlazados, no Studio.',[BASE,"capability=toolkit.skill(name='arithmetic',tools=(increment,),instructions='Use integer arithmetic.')\nworker=toolkit.Agent('worker',graph=graph,skills=(capability,))\nassert worker.run({'value':3}).data=={'value':4}\nprint(capability.inspect())",md('Carga portable: [carpeta completa](../../examples/portable_skills/assets/arithmetic). SKILL.md documenta; skill.py construye la Skill.'),ROOT_SETUP+"\nloaded=toolkit.load_skill(ROOT/'examples/portable_skills/assets/arithmetic')\nassert loaded.tools[0].run({'value':3}).data=={'value':4}\nprint(loaded.inspect())"])
common=json.loads((ROOT/'examples/common_graph/01_common_graph.ipynb').read_text(encoding='utf-8'))
codes=[(''.join(c['source']).replace('2.1.4.dev2',V)) for c in common['cells'] if c['cell_type']=='code']
init=codes[0].replace('assert toolkit.__version__ == "2.1.4.dev3"','assert toolkit.__version__ == "2.1.4.dev3"')
save('tutorials/core/02_agent_flows.ipynb','Agent: secuencia, ramas y decisiones','Un constructor Agent, un StateGraph. Input value=2 → proceso visible → 6, 7 y 6. El paralelo usa campos distintos y una barrera.',[code(init),md('Secuencia'),code(codes[1]),md('Paralelo: dos ramas y barrera'),code(codes[3]),md('Decisión: una función normal'),code(codes[5])])
left_defs=codes[3].split('graph = StateGraph')[0]
save('tutorials/core/03_system_flows.ipynb','System: coordinar Agents','La gramática del grafo es la misma. Los nodos ahora son Agents. LangGraph sigue siendo el único motor.',[code(init),code(codes[2]),code(left_defs),code(codes[4]),code(codes[6])])
episode=(ROOT/'examples/episode_memory/example.py').read_text(encoding='utf-8').split('def run():')[0]
lesson('tutorials/core/04_environment.ipynb','Environment: observar y transicionar','Input 2, 3, 100 → observe/run/update/stop → total=5, dos registros. state es estado del episodio; Memory guarda episodios terminados. No hay reset/step/reward públicos.',[episode,"episode=build()\nresult=episode.run()\nassert result.ok and result.data['summary']['state']=={'total':5}\nassert result.data['summary']['processed']==2\nprint(result.data['summary'])"])
lesson('tutorials/core/05_eval.ipynb','Eval: comprobar lo observado','Input value=3 → Agent suma uno → Eval exige 4. Un control negativo exige 999 y debe fallar. Eval es explícito y transversal a Agent, System y Environment.',[BASE,"evaluation=toolkit.Eval('correctness',agent,cases=({'input':{'value':3},'expected':{'data':{'value':4}}},))\npassed=evaluation.run()\nnegative=toolkit.Eval('negative',agent,cases=({'input':{'value':3},'expected':{'data':{'value':999}}},)).run()\nassert passed.ok and not negative.ok\nprint({'positive':passed.ok,'negative_detected':not negative.ok})",md('Eval termina ante el primer caso fallido. Para medir todas las decisiones negativas, ejecutar casos independientes. Un juez fixture comprueba el protocolo; no acredita juicio semántico.')])
lesson('tutorials/core/06_results_limits.ipynb','Resultados, límites y linaje','compile construye; run/arun ejecutan. RunResult conserva contrato común, IDs y evidencia; lineage ofrece vistas humanas y para agentes.',[BASE,"import asyncio, json\nprogram=agent.compile()\nresult=program.run({'value':3},limits=toolkit.Limits(max_actions=10,timeout_s=10))\nasync_result=await program.arun({'value':3})\nrestored=toolkit.RunResult(**json.loads(json.dumps(result.to_dict())))\nassert result.ok and async_result.data==result.data and restored.check_invariants().ok\nprint(restored.lineage().render())\nprint(restored.lineage().to_prompt_context())"])
lesson('tutorials/core/07_order_challenge.ipynb','Pedidos: siete Agents','Ejemplo aplicado del repositorio. [Declaración completa](../../examples/order_fulfillment/system.py). Input siete casos → Tools, paralelo, política y decisión → recibos; incluye fallo de inventario y Eval negativo. No hay pedidos reales ni inferencia.',[ROOT_SETUP,"from examples.order_fulfillment import verify\nreport=verify()\nassert report['cases_passed']==7\nprint([(case['name'],case['ok'],case['output']) for case in report['cases']])"])
api_source=(ROOT/'examples/api_214/application.py').read_text(encoding='utf-8').split('def demonstrate():')[0]
lesson('tutorials/core/08_context_memory.ipynb','Context, Memory y linaje','Context fija semántica y fuentes; Memory conserva episodios; lineage explica ejecuciones precedentes. State contiene los datos de trabajo. Input subtotal=100 → impuesto del Context → total=116 MXN.',[api_source,"result=agent.run({'subtotal':100})\nassert result.ok and result.data['total']==116\nassert len(memory.read())==1\nprint(domain.to_dict())\nprint(result.lineage().render())"])
VERIFY="""@toolkit.tool
def certify(value:int)->dict:
    return {'value':value,'verified':True}
capability=toolkit.skill(name='evidence',tools=(certify,))
"""
ACTOR="""actor=toolkit.Agent('verification',runtime=runtime,framework=toolkit.framework(actor_framework),
    skills=(capability,),instructions='Call certify once with the supplied value. The Tool output is the result.',
    contract={'tool_expectation':{'all_of':['certify']},'completion':'when_required_tools_satisfied'},policy={'repair':False})
result=actor.run({'value':37},limits=toolkit.Limits(max_actions=30,timeout_s=120))
events=[event for node in result.walk() for event in node.tool_events]
assert result.ok and result.check_invariants().ok, result.to_dict()
assert any(e.name=='certify' and e.ok and e.input=={'value':37} for e in events)
print({'input':{'value':37},'process':'runtime + actor -> Tool event','output':result.data})
"""
lesson('tutorials/providers/00_python.ipynb','Python Runtime','El mismo actor y diccionario de entrada, sin LM. Una Tool por actor Python; varias operaciones se coordinan con StateGraph.',[VERIFY,"actor_framework='native'\nruntime=toolkit.runtime(provider='python-runtime')",ACTOR])
for path,title,provider,config in [
 ('01_openai','OpenAI API key','openai-runtime',"model=os.getenv('OPENAI_MODEL_ID') or os.environ['OPENAI_MODEL'],api_key=os.environ['OPENAI_API_KEY'],endpoint=os.getenv('OPENAI_BASE_URL')"),
 ('02_ollama','Ollama Cloud API key','ollama-runtime',"model=os.environ['OLLAMA_MODEL'],api_key=os.environ['OLLAMA_API_KEY'],endpoint=os.environ['OLLAMA_BASE_URL']"),
 ('03_bedrock','Bedrock API key','bedrock-runtime',"model=os.environ['BEDROCK_MODEL_ID'],api_key=os.environ['AWS_BEARER_TOKEN_BEDROCK'],region=os.getenv('AWS_REGION') or os.environ['AWS_DEFAULT_REGION']"),
 ('05_ollama_gpu','Ollama GPU local','ollama-runtime',"model=os.getenv('OLLAMA_GPU_MODEL','qwen3:4b-instruct-2507-q4_K_M'),endpoint=os.getenv('OLLAMA_GPU_BASE_URL','http://127.0.0.1:11434/v1'),api_key='ollama-local'")]:
    setup="import os\nruntime=toolkit.runtime(provider="+repr(provider)+","+config+",max_tokens=512,max_turns=3,max_tool_calls=1,max_retries=0,timeout_s=90)\n"
    if provider!='openai-runtime':setup+="assert 'qwen' in runtime.model.lower(), 'This campaign requires Qwen; do not substitute a model'\n"
    setup+="print({'provider':runtime.provider,'model':runtime.model})"
    save('tutorials/providers/'+path+'.ipynb',title,'Input value=37 → llamada real de Tool → evidencia. Las celdas live consumen inferencia y requieren presupuesto activo en la campaña. No se reintenta ni se cambia de modelo. Offline solo valida las declaraciones independientes.',[code(IMPORTS),code(VERIFY),code("actor_framework='native'",('parameters',)),code(setup,('live',)),code(ACTOR,('live',))])
lesson('tutorials/providers/04_vllm_serving.ipynb','Qwen y vLLM: preparación','Declarar artefacto/servidor no arranca GPU ni descarga pesos. [Preparar WSL](../../docs/VLLM_GPU_214.md). Se registra pendiente si falta el endpoint.',["artifact=toolkit.model_artifact('Qwen/Qwen3-0.6B',revision='main',metadata={'scope':'declaration only'})\nserver=toolkit.model_server(artifact,max_model_len=2048,max_num_seqs=1,gpu_memory_utilization=0.75)\nprint(artifact.inspect())\nprint(server.inspect())",code(VERIFY+"\nactor_framework='native'\nruntime=toolkit.runtime(provider='vllm-runtime',model='Qwen/Qwen3-0.6B',endpoint='http://127.0.0.1:8000/v1',api_key='vllm',max_tokens=512,max_retries=0)\n"+ACTOR,('live','target-required'))])
lesson('tutorials/frameworks/01_langgraph.ipynb','LangGraph: orquestación y pausa','LangGraph no es un cuarto actor. State/nodes/edges coordinan Agents, Systems y Environments. compile prepara; run puede pausar; resume consume una continuación local al mismo programa.',["class State(TypedDict,total=False):\n    amount:int\n    approved:bool\ngraph=StateGraph(State)\ngraph.add_node('approval',lambda state:{'approved':toolkit.pause({'amount':state['amount'],'question':'Approve?'})})\ngraph.add_edge(START,'approval')\ngraph.add_edge('approval',END)\nprogram=toolkit.Agent('approval',graph=graph).compile()\nwaiting=program.run({'amount':280})\nassert waiting.status=='paused'\nfinished=program.resume(waiting,True)\nassert finished.ok and finished.data['approved']\nprint(finished.data)"])
for path,title,framework in [('02_openai_agents','OpenAI Agents: actor y handoff','openai-agents'),('03_strands','AWS Strands: actor, MCP y A2A','strands')]:
    cells=[code(IMPORTS),code(VERIFY),code("actor_framework="+repr(framework)+"\nruntime=toolkit.runtime(provider='python-runtime')"),code(ACTOR)]
    if framework=='openai-agents':
        cells += [md('Handoff, sesión y guardrail: [laboratorio completo](../../examples/agentic_systems_studio/src/agentic_systems_studio/lab/probes.py). Requiere el paquete Studio local dev3; Python verifica el protocolo, no razonamiento.'),code("from agentic_systems_studio.lab.probes import handoffs\nreport=handoffs('openai-runtime')\nassert report['handoff_callback'] and not report['guardrail_negative']['ok']\nprint(report['handoff_callback'])",('live',))]
    else:
        cells += [md('MCP/A2A usa servidores locales reales. [Laboratorio](../../examples/patterns/strands_protocol_graph/example.py). Estas celdas se ejecutan en el perfil separado de servicios locales, sin inferencia, y cierran sus procesos.'),code("from examples.patterns.strands_protocol_graph.example import run\nimport asyncio\nreport=await asyncio.to_thread(run)\nprint(report)",('local-service',))]
    save('tutorials/frameworks/'+path+'.ipynb',title,'Una implementación de actor, bajo la misma orquestación LangGraph y el mismo RunResult.',cells)
lesson('tutorials/frameworks/04_interoperability.ipynb','Tres actores en un System','native, OpenAI Agents y Strands son tres actores consecutivos en un único StateGraph. Input 42 → cada Tool suma uno y registra su identidad → 45. [Declaración completa](../../examples/agentic_systems_studio/src/agentic_systems_studio/lab/interop.py).',["from agentic_systems_studio.lab.interop import run\nreport=run()\nassert report['output']['data']['value']==45\nprint(report['output']['data'])"])
lesson('tutorials/api/01_runtime_framework.ipynb','Runtime y framework: dos ejes','LangGraph orquesta. Runtime selecciona ejecución; framework selecciona actor. native, openai-agents y strands usan la misma entrada/salida pública. Los esquemas y Limits acotan el trabajo; no hay fallback.',["from examples.validation.provider_framework_conformance.example import run\nreport=run()\nassert len(report['rows'])==3\nprint([(row['framework'],row['result']['data']) for row in report['rows']])","print(toolkit.runtime(provider='python-runtime').inspect())\nprint(toolkit.framework('native').inspect())"])
lesson('tutorials/api/02_contracts_judges.ipynb','Contratos y juez explícito','Contratos positivos/negativos en los tres actores; después, un juez fixture que no puede sobreescribir una expectativa exacta fallida. El fixture no acredita evaluación semántica.',["from examples.agent_contracts.example import run\nreport=run()\nassert len(report['output'])==3\nprint([(row['framework'],row['positive']['ok'],row['negative']['ok']) for row in report['output']])","from examples.evaluation_checks.example import run as evaluate\nreport=evaluate()\nassert report['output']['ok'] and not report['negative']['ok']\nprint(report['judge_validation'])"])
# Existing current notebooks retain their demonstrations; update their version and outputs.
for relative in ['examples/common_graph/01_common_graph.ipynb','examples/context_memory_lineage/01_context_memory_lineage.ipynb','examples/api_214/01_api.ipynb']:
    p=ROOT/relative;nb=nbformat.read(p,4)
    for c in nb.cells:
        c.source=c.source.replace('2.1.4.dev2',V)
        if c.cell_type=='code':c.execution_count=None;c.outputs=[]
    nbformat.write(nb,p)
source=(ROOT/'examples/api_214/application.py').read_text(encoding='utf-8').split('def demonstrate():')[0]
save('examples/api_walkthrough/01_api_user_guide.ipynb','Toda la API: de Tool a Eval','Input subtotales 100 y 200 → Context, Tool, Skill, Agent, decisión del System y Environment → total acumulado 348. La fuente es visible aquí; Python, sin inferencia.',[code(source),code("single=agent.run({'subtotal':100})\nteam=system.run({'subtotal':100})\nbatch=environment.run()\nchecked=evaluation.run()\nassert single.ok and team.ok and batch.ok and checked.ok\nassert batch.data['summary']['state']=={'sum':348}\nprint(single.data,team.data,batch.data['summary'])\nprint(batch.lineage().render())")])
save('examples/agentic_systems_studio/notebooks/01_studio.ipynb','Studio: conversación y evidencia','Instala el Studio local dev3 contra el wheel dev3. El caso Python prueba el controlador de conversación; la interfaz web tiene un perfil local separado. No demuestra por sí solo todos los controles de UI.',[code(IMPORTS),code("from agentic_systems_studio import ConversationConfig, build_conversational_system\nconfig=ConversationConfig(provider='python-runtime',framework='native',max_response_repairs=0)\napp=build_conversational_system(config)\nresult=app.run('Hola')\nassert result.ok and result.data['history_turns']==0, result.to_dict()\nprint(result.data)"),md('Interfaz web local: iniciar explícitamente; cerrar el servidor con server.stop().'),code("from agentic_systems_studio.server import start_studio_server\nserver=start_studio_server()\nprint(server.local_url)\nserver.stop()",('local-service',))])
print('Notebooks refreshed: 21 tutorials and 5 examples')
