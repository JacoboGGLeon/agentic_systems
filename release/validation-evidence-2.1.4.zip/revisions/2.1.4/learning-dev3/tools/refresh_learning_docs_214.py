"""Maintain the current learning map and label historical material explicitly."""
from pathlib import Path
import ast, json, os, re
ROOT=Path(__file__).resolve().parents[1]
E=ROOT/'revisions/2.1.4/learning-dev3'
V='2.1.4.dev3'
def write(path,text):
    p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+"\n",encoding='utf-8')
def link(source,target):return os.path.relpath(ROOT/target,(ROOT/source).parent).replace(os.sep,'/')
current={'README.md','API_214.md','API_214_SURFACE.md','GRAMMAR_214.md','GRAMMAR_COVERAGE_214.md','CONTRACTS_214.md','LEARNING_PLAN_214.md','LEARNING_VALIDATION_214.md','NOTEBOOK_INVENTORY_214.md','RUNRESULTS_LINEAGE_214.md','VLLM_GPU_214.md'}
redirects={
'API.md':('API de usuario','API_214.md'),
'API_CONTRACT.md':('Contratos de API','CONTRACTS_214.md'),
'RUNRESULT_CONTRACT.md':('Resultados y linaje','API_214.md'),
'RUNTIME_AND_FRAMEWORK_CONTRACTS.md':('Runtime, framework y orquestación','API_214.md'),
'ARCHITECTURE.md':('Arquitectura','GRAMMAR_214.md'),
'COMPUTATIONAL_MODEL.md':('Modelo computacional','GRAMMAR_214.md'),
'COMPOSITION_LAWS.md':('Composición','GRAMMAR_214.md'),
'ONBOARDING_FIRST_RUN.md':('Primer recorrido','../tutorials/README.md'),
'CLI.md':('CLI y scaffolder','../INSTALL.md')}
for name,(title,target) in redirects.items():
    write('docs/'+name,'# '+title+' · '+V+'\n\nLa referencia vigente es ['+title+']('+target+'). LangGraph es el único orquestador; native, openai-agents y strands implementan actores. Los resultados y límites reales están en [validación](LEARNING_VALIDATION_214.md). La versión anterior de este documento se conserva en before-learning.zip del informe de auditoría.')
for p in (ROOT/'docs').rglob('*.md'):
    if p.name in current or p.name in redirects:continue
    s=p.read_text(encoding='utf-8')
    if s.startswith('> **Histórico'):continue
    target=os.path.relpath(ROOT/'docs/API_214.md',p.parent).replace(os.sep,'/')
    p.write_text('> **Histórico: no es la guía de la API '+V+'.** Conserva propuestas/resultados de su versión original. Para implementar, usa [la API vigente]('+target+').\n\n'+s,encoding='utf-8')
for name in ['API_214.md','API_214_SURFACE.md','GRAMMAR_214.md','CONTRACTS_214.md','GRAMMAR_COVERAGE_214.md','VLLM_GPU_214.md']:
    p=ROOT/'docs'/name;s=p.read_text(encoding='utf-8').replace('2.1.4.dev2',V)
    s=s.replace('revisions/2.1.4/runtime-evidence/REPORT.md','revisions/2.1.4/learning-dev3/REPORT.md')
    if name=='API_214.md':s+='\n\nLa campaña didáctica vigente está en [validación](LEARNING_VALIDATION_214.md). Eval es fail-fast; ejecutar casos negativos independientes permite observar cada decisión. La prueba de Studio distingue controlador, interfaz y protocolos.\n'
    if name=='VLLM_GPU_214.md':s=re.sub(r'El saldo actual es.*?presupuesto nuevo\.', 'La campaña vigente y su saldo están en LEARNING_VALIDATION_214.md. No iniciar inferencia sin un contador activo.', s,flags=re.S)
    p.write_text(s,encoding='utf-8')
write('tutorials/README.md',"""# Tutorials · Agentic Systems 2.1.4.dev3

Empieza por core/00 y ejecuta las celdas en orden. Cada lección explica
input → proceso → output y contiene aserciones. Usamos `import agentic_systems
as toolkit` y StateGraph de LangGraph; no hay backend alternativo.

Instala el wheel local y los extras en [INSTALL](../INSTALL.md). Core funciona
sin Studio salvo los recursos del repositorio enlazados. Las secciones avanzadas
que usan Studio lo indican expresamente. El wheel no instala estos notebooks.

## Core

| Lección | Qué aprendes |
| --- | --- |
| [00 Inicio](core/00_start.ipynb) | Tool, Agent y RunResult |
| [01 Tools/Skills](core/01_tools_skills.ipynb) | Capacidades y load_skill |
| [02 Agent](core/02_agent_flows.ipynb) | Secuencia, ramas y decisiones |
| [03 System](core/03_system_flows.ipynb) | Coordinar Agents con la misma gramática |
| [04 Environment](core/04_environment.ipynb) | state, observe, update, stop y Memory |
| [05 Eval](core/05_eval.ipynb) | Expectativas y control negativo |
| [06 Resultados](core/06_results_limits.ipynb) | compile/run/arun, Limits, JSON y linaje |
| [07 Pedidos](core/07_order_challenge.ipynb) | Siete Agents y siete casos de negocio |
| [08 Context/Memory](core/08_context_memory.ipynb) | Semántica, episodios y evidencia |

## Providers

| Lección | Alcance |
| --- | --- |
| [00 Python](providers/00_python.ipynb) | Operador real, sin LM |
| [01 OpenAI API key](providers/01_openai.ipynb) | Tool y evidencia live |
| [02 Ollama Cloud](providers/02_ollama.ipynb) | API key; necesita un Qwen disponible en el catálogo |
| [03 Bedrock API key](providers/03_bedrock.ipynb) | Qwen, región y bearer token; no acredita IAM |
| [04 vLLM](providers/04_vllm_serving.ipynb) | Declaración offline; GPU/endpoint pendientes |
| [05 Ollama GPU](providers/05_ollama_gpu.ipynb) | Qwen local y evidencia de asignación GPU |

Las celdas live consumen inferencia. La prueba offline las omite explícitamente;
no acredita su generación. No hay sustitución automática de proveedor/modelo.

## Orquestación y frameworks

| Lección | Capacidad |
| --- | --- |
| [01 LangGraph](frameworks/01_langgraph.ipynb) | Único orquestador, pausa/reanudación |
| [02 OpenAI Agents](frameworks/02_openai_agents.ipynb) | Actor Python; handoff/sesión/guardrail live |
| [03 AWS Strands](frameworks/03_strands.ipynb) | Actor; MCP/A2A en perfil de servicios locales |
| [04 Interoperabilidad](frameworks/04_interoperability.ipynb) | Tres actores en un System |

native es el actor propio del toolkit, no un alias de LangGraph. AWS Strands
se selecciona con `framework('strands')`. Los modelos fixture de protocolos
no acreditan razonamiento de un LM.

## API

[01 Runtime/framework](api/01_runtime_framework.ipynb) separa los ejes.
[02 Contratos/jueces](api/02_contracts_judges.ipynb) añade negativos y un juez fixture.

[Inventario por notebook](../docs/NOTEBOOK_INVENTORY_214.md) ·
[Validación y pendientes](../docs/LEARNING_VALIDATION_214.md) ·
[Examples](../examples/README.md) · [Firmas completas](../docs/API_214_SURFACE.md)
""")
cat=json.loads((ROOT/'examples/catalog.json').read_text(encoding='utf-8'))
if 'original_catalog_baseline' not in cat:cat['original_catalog_baseline']=cat.get('baseline')
cat['schema_version']='agentic-systems.examples-catalog.v2';cat['api_version']=V
cat['validation_report']='revisions/2.1.4/learning-dev3/REPORT.md'
cat['baseline']={'version':V,'wheel_sha256':'83cf3dca623e57d335b02136e70e9fe13dc5dd0ffbc0cc633b8cdcbda430aab9'}
summary=['# Examples · '+V,'','Implementaciones con una sola gramática: StateGraph de LangGraph. Desde la raíz del checkout, con el wheel instalado:','','```python','from examples.applications.research_synthesis.example import run','result = run()','print(result.data)','```','','Cada ejemplo conserva un objetivo concreto y controles verificables. Python es ejecución real determinista; las fixtures no son razonamiento de un LM. Los protocolos locales, la inferencia y la UI tienen evidencias separadas.','','[Tutorials](../tutorials/README.md) · [API](../docs/API_214.md) · [Validación](../docs/LEARNING_VALIDATION_214.md) · [RunResults y linaje](../docs/RUNRESULTS_LINEAGE_214.md)','','| Ejemplo | Qué muestra | Perfil |','| --- | --- | --- |']
for x in cat['entries']:
    x.setdefault('historical_validation',x.get('validation',{}))
    x['api_version']=V
    x['title']=x['title'].replace('2.1.3',V).replace('Cuatro frameworks','Tres actores').replace('four frameworks','three actors')
    sources=x.get('sources',[])
    entry=next((s['target'] for s in sources if s['target'].endswith('/example.py')),None)
    if x['id']=='studio':entry='examples/agentic_systems_studio/example.py'
    if x['id']=='order_fulfillment_213':entry='examples/order_fulfillment/example.py'
    if x['id']=='api_walkthrough':entry='examples/api_walkthrough/example.py'
    if entry:
        ev=E/'examples'/(entry.replace('/','--')+'.json')
        status='pending';passed=None
        if ev.exists():
            r=json.loads(ev.read_text(encoding='utf-8'));passed=r['passed'];status=r.get('status','failed')
        if 'strands_protocol_graph' in entry:status='local-protocol-profile';passed=None
        x['validation']={'status':status,'wheel_sha256':cat['baseline']['wheel_sha256'],'evidence':[{'target':str(ev.relative_to(ROOT)).replace(os.sep,'/')}],'scope':'Current entrypoint assertions and RunResult invariants; online actor projections are separately enumerated'}
        x['entrypoint']=entry
        readme=ROOT/Path(entry).parent/'README.md'
    else:
        status='documentation-index';x['validation']={'status':status,'scope':'The linked notebooks are executed individually'}
        readme=ROOT/'examples/patterns/api_213_tutorials/README.md'
    x['purpose']=x.get('purpose','').replace('2.1.3',V).replace('four SDKs','three SDKs').replace('cuatro','tres')
    text='# '+x['title']+' · '+V+'\n\n'+x['purpose']+'\n\n'
    if entry:
        module=entry[:-3].replace('/','.')
        text+='```python\nfrom '+module+' import run\nreport = run()\n```\n\n'
        text+='Input → proceso → output: '+x.get('flow','ver la muestra y las aserciones de la implementación').replace('2.1.3',V)+'\n\n'
        text+='[Declaración]('+link(readme.relative_to(ROOT),entry)+') · [Evidencia]('+link(readme.relative_to(ROOT),str(ev.relative_to(ROOT)))+')\n\n'
    text+='Perfil actual: **'+status+'**. El catálogo [de validación]('+link(readme.relative_to(ROOT),'docs/LEARNING_VALIDATION_214.md')+') separa configuración, Python, servicios locales y pruebas de modelos. La evidencia 2.1.3 conservada es histórica y no certifica estos bytes.\n'
    readme.parent.mkdir(parents=True,exist_ok=True);readme.write_text(text,encoding='utf-8')
    summary.append('| ['+x['title']+']('+str(readme.relative_to(ROOT/'examples')).replace(os.sep,'/')+') | '+x['purpose'].replace('|','/')+' | '+status+' |')
summary+=['','## Recorridos completos','','- [API integrada](api_214/01_api.ipynb).','- [Seis formas, contexto, pausas y recursos](common_graph/01_common_graph.ipynb).','- [Context, Memory y linaje](context_memory_lineage/01_context_memory_lineage.ipynb).','','Las carpetas history/ y evidence/ conservan procedencia. No son otra gramática soportada. Los directorios de build son cachés, no ejemplos vigentes. Los ejemplos de configuración de vLLM/IAM no equivalen a validar esos entornos.']
write('examples/README.md','\n'.join(summary))
(ROOT/'examples/catalog.json').write_text(json.dumps(cat,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
write('docs/README.md',"""# Documentación · 2.1.4.dev3

1. [Instala el wheel y Studio locales](../INSTALL.md).
2. [Aprende por core, providers, frameworks y API](../tutorials/README.md).
3. [Elige una implementación](../examples/README.md).
4. [Consulta la API](API_214.md) y [todas las firmas](API_214_SURFACE.md).
5. [Comprueba validación y pendientes](LEARNING_VALIDATION_214.md).

[Plan de mejora](LEARNING_PLAN_214.md) · [Gramática](GRAMMAR_214.md) ·
[Contratos](CONTRACTS_214.md) · [Inventario](NOTEBOOK_INVENTORY_214.md) ·
[RunResults y linaje](RUNRESULTS_LINEAGE_214.md) · [vLLM GPU](VLLM_GPU_214.md)

Los informes y propuestas anteriores llevan un aviso histórico. Conservan sus
resultados originales; no enseñan una segunda API compatible. El SDK sigue
siendo un desarrollo local, sin publicación de esta revisión.
""")
write('INSTALL.md',"""# Instalación local · 2.1.4.dev3

Esta revisión no está publicada. Desde la raíz del checkout instala el wheel
local exacto, sus extras y la aplicación Studio separada:

```bash
python -m venv .venv-user
# Activar el entorno según tu sistema.
python -m pip install "revisions/2.1.4/json-markdown-fix/candidate/agentic_systems-2.1.4.dev3-py3-none-any.whl[openai,bedrock,openai-agents,strands]"
python -m pip install ./examples/agentic_systems_studio
python -m pip install jupyterlab ipykernel
python -m ipykernel install --user --name agentic-dev3
python -m jupyterlab
```

Selecciona ese kernel. Los notebooks y ejemplos son archivos del checkout;
`pip install agentic-systems` desde PyPI no instala este desarrollo ni Studio.
Instala `examples/agentic_systems_studio[ui,notebook]` para la interfaz/widgets.

```python
import agentic_systems as toolkit
assert toolkit.__version__ == '2.1.4.dev3'
```

Para Python no hacen falta claves. Los proveedores usan variables de entorno:
OPENAI_API_KEY y OPENAI_MODEL; AWS_BEARER_TOKEN_BEDROCK, BEDROCK_MODEL_ID y
AWS_REGION; OLLAMA_API_KEY, OLLAMA_MODEL y OLLAMA_BASE_URL. GPU local usa el
endpoint explícito de su notebook. Nunca pegues claves en notebooks o Context.

Qwen Cloud requiere que el catálogo del servicio lo ofrezca; no se sustituye
por Gemma. vLLM necesita preparar Linux/WSL y GPU antes de probarlo:
[guía](docs/VLLM_GPU_214.md). API-key Bedrock no certifica IAM ni ADA.

```bash
agentic-systems new mi_proyecto
cd mi_proyecto
python app.py
```

El scaffolder genera fuente, recursos, notebook y manifiesto. La skill dev3
agrega además un test de contrato. Generar no es validar: ejecuta la aplicación
y sus aserciones contra el mismo wheel. [Tutorials](tutorials/README.md).
""")
write('examples/agentic_systems_studio/README.md',"""# Agentic Systems Studio · 2.1.4.dev3

Studio es una aplicación separada del SDK. Instala el wheel dev3 y luego
`python -m pip install "./examples/agentic_systems_studio[ui,notebook]"`.
Abre [el notebook](notebooks/01_studio.ipynb) o inicia la interfaz:

```bash
python -m streamlit run examples/agentic_systems_studio/src/agentic_systems_studio/ui.py
```

```python
from agentic_systems_studio import ConversationConfig, build_conversational_system
app = build_conversational_system(ConversationConfig(provider='python-runtime', framework='native'))
result = app.run('Hola')
assert result.ok
print(result.data)
```

El controlador usa StateGraph; native, openai-agents y strands son actores.
El estado interno de cada nodo lleva una envoltura payload de negocio, no
árboles de resultados. El resultado público conserva answer, historial,
validación, eventos y linaje. Las claves quedan fuera del estado.

Las pruebas separan controlador/conversación, UI, handoffs y MCP/A2A. Los
servicios locales usan fixtures sin LM; la integración con actores LM se prueba
aparte. [Matriz, evidencia y pendientes](../../docs/LEARNING_VALIDATION_214.md).

Para inferencia configura las variables de entorno y AGENTIC_BUDGET_FILE con
un contador persistente autorizado. La prueba de Python no acredita calidad de
conversación de un modelo ni todos los controles de la interfaz.
""")
print('Current maps, catalog and historical boundaries refreshed.')
