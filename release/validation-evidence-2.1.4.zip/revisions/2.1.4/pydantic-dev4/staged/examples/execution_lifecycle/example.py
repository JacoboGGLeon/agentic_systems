import asyncio
import agentic_systems as toolkit
from examples.grammar_tour.example import build

def run():
    unit = build()[0]
    prepared = unit.compile()
    direct = unit.run({'value': 3}, limits=toolkit.Limits(max_actions=2))
    asynchronous = asyncio.run(prepared.arun({'value': 3}))
    limited = unit.run({'value': 3}, limits=toolkit.Limits(max_actions=1))
    assert direct.ok and direct.data == asynchronous.data == {'value': 8}
    assert not limited.ok
    return {'input': {'value': 3}, 'process': prepared.inspect(), 'output': direct.to_dict(), 'limit_failure': limited.to_dict()}
