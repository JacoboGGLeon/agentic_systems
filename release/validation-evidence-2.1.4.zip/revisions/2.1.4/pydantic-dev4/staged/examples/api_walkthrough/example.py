"""Integrated current API; the source is examples/api_214/application.py."""
from examples.api_214.application import demonstrate

def run():
    return demonstrate()
