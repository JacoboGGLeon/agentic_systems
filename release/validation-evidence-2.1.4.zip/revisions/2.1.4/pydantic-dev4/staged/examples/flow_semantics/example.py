"""Canonical six-form application; implementation is linked in README."""
from examples.grammar_tour.example import build, run
