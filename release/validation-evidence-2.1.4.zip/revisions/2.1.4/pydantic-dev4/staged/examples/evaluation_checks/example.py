import pydantic
from typing import Any
from dataclasses import replace
import agentic_systems as toolkit
from examples.episode_memory.example import build as build_episode

class State(pydantic.BaseModel):
    value: Any
    input: Any
    expected: Any | None = None
    result: Any | None = None
    rubric: Any | None = None
    criteria: Any | None = None
    findings: Any | None = None
    rationale: Any | None = None

def run():

    class Output1(pydantic.BaseModel):
        value: Any
    graph_1 = toolkit.StateGraph(State, output_schema=Output1)
    graph_1.add_node('increment', lambda d: {'value': d.value + 1})
    graph_1.add_edge(toolkit.START, 'increment')
    graph_1.add_edge('increment', toolkit.END)
    target = toolkit.Agent('calculator', graph=graph_1)

    class Output2(pydantic.BaseModel):
        criteria: Any
        findings: Any
        rationale: Any
    graph_2 = toolkit.StateGraph(State, output_schema=Output2)
    graph_2.add_node('score', lambda payload: {'criteria': {'correctness': 1.0}, 'findings': [], 'rationale': 'Fixture: deterministic oracle confirmed the supplied case.'})
    graph_2.add_edge(toolkit.START, 'score')
    graph_2.add_edge('score', toolkit.END)
    judge = toolkit.Agent('fixture_judge', graph=graph_2)
    evaluation = toolkit.Eval('contract', target, ({'input': {'value': 3}, 'expected': {'data': {'value': 4}}},), checks=(lambda result, case: {'ok': result.data['value'] > 0, 'issues': []},), judge=judge, rubric={'criteria': ['correctness'], 'threshold': 0.9})
    positive = evaluation.run()
    negative = replace(evaluation, cases=({'input': {'value': 3}, 'expected': {'data': {'value': 999}}},)).run()
    episode = toolkit.Eval('episode_reward', build_episode(), ({'input': {}, 'expected': {'ok': True}},), checks=(lambda result, case: {'ok': result.data['summary']['state']['total'] == 5, 'issues': [], 'metrics': {'reward': result.data['summary']['state']['total']}},)).run()
    assert positive.ok and (not negative.ok) and episode.ok
    assert episode.data['cases'][0]['checks'][1]['metrics']['reward'] == 5
    return {'input': {'value': 3}, 'process': 'Exact expected + check + explicit fixture judge; separate episode check', 'output': positive.to_dict(), 'negative': negative.to_dict(), 'episode': episode.to_dict(), 'judge_validation': 'fixture-only; no semantic model inference'}
