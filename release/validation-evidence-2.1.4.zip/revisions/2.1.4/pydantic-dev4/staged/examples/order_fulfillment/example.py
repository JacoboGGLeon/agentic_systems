"""Seven business cases plus episode, Eval and negative control."""
from .verification import verify

def run():
    report = verify()
    assert report['cases_passed'] == 7
    return report
