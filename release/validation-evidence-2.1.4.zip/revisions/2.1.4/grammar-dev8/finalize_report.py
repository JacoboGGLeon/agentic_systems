"""Bind completed offline checks to the installed dev8 wheel and document scope."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
E = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    installation = read(E / "installation.json")
    summary = read(E / "summary.json")
    assert summary["wheel_sha256"] == installation["wheel_sha256"]
    assert summary["tests"] == dict(tests=469, failures=0, errors=0, skipped=0)
    assert summary["notebooks"] == 30 and summary["examples_passed"] == 58
    assert read(E / "pyright-final.json")["summary"]["errorCount"] == 0
    notebook_results = sorted((E / "closure/notebook-runs").glob("*/results.json"))[-1]
    notebooks = read(notebook_results)
    assert len(notebooks) == 30 and all(row["passed"] for row in notebooks)
    inventory = read(ROOT / "docs/NOTEBOOK_INVENTORY_214.json")
    skipped = sum(len(row["skipped_cells"]) for row in inventory["notebooks"])
    budget = ROOT / "revisions/2.1.4/contracts-dev5/campaign-budget.json"
    assert sha(budget) == "6ce1ae54e97e11835598312e56ca403ca7b267478a99ce1bc5c93a0bdbd5b9e6"

    catalog_path = ROOT / "examples/catalog.json"
    catalog = read(catalog_path)
    catalog["baseline"] = {"version": summary["version"], "wheel_sha256": installation["wheel_sha256"]}
    examples = read(E / "closure/examples-offline.json")
    assert examples["offline_guard_blocked_attempts"] == 0
    bypath = {row["path"]: row for row in examples["rows"]}
    for entry in catalog["entries"]:
        old = entry.get("validation", {})
        path = entry.get("entrypoint") or old.get("entrypoint")
        row = bypath.get(path)
        if row and row.get("passed"):
            if old.get("version") == "2.1.4.dev8" and old.get("wheel_sha256") != installation["wheel_sha256"]:
                entry.setdefault("historical_validation_dev8_build05", old.copy())
            configuration = any(part in path for part in ("validation/aws_iam/", "validation/ada_iam/", "validation/vllm_colab/", "aws_session/"))
            status = "configuration-offline-passed" if configuration else "offline-passed"
            entry.update(api_version=summary["version"], readiness=status)
            entry["validation"] = {"version": summary["version"], "status": status, "entrypoint": path,
                                   "wheel_sha256": installation["wheel_sha256"], "source_sha256": row["source_sha256"],
                                   "report": "revisions/2.1.4/grammar-dev8/closure/examples-offline.json",
                                   "scope": "Offline only; configuration/SDK fixtures do not certify live services or the complete Studio UI."}
        if entry["id"] == "api_213_tutorials":
            entry.setdefault("historical_validation_dev5", old.copy())
            entry.update(title="Tutorials de la API dev8", purpose="22 notebooks por core, providers, frameworks y API.",
                         flow="Instalar el wheel dev8 → construir → ejecutar → comprobar; live y servicios locales quedan separados.",
                         api_version=summary["version"], readiness="offline-profile-passed",
                         sources=[{"label": "Curso actual", "target": "tutorials/README.md"}, {"label": "API vigente", "target": "docs/API_214.md"}],
                         validation={"version": summary["version"], "status": "offline-profile-passed", "wheel_sha256": installation["wheel_sha256"], "report": "docs/NOTEBOOK_INVENTORY_214.md"})
    catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    cli = ROOT / "docs/CLI.md"
    cli.write_text(cli.read_text(encoding="utf-8").replace("scaffolder-build05", "scaffolder-build07"), encoding="utf-8")

    bound = [E / name for name in ("installation.json", "summary.json", "installed-suite-closure.xml", "source-suite-closure.xml",
             "installed-coverage-closure.json", "integrity-build07.json", "pyright-final.json", "docs-smoke-build07.json",
             "installed-smoke-build07.json", "closure/examples-offline.json", "closure/scaffolder-build07/scaffolder.json",
             "skill-validation.json", "skill-generated-tests.xml")]
    bound += [notebook_results, E / "delivery-build07/manifest.json"]
    verification = {"version": summary["version"], "wheel_sha256": installation["wheel_sha256"],
                    "installed_site": installation["site"], "offline_passed": True, "live_passed": False,
                    "python_versions_verified_locally": ["3.14"], "remote_ci": "pending", "inference_requests": 0,
                    "budget_unchanged_sha256": sha(budget),
                    "evidence_sha256": {p.relative_to(ROOT).as_posix(): sha(p) for p in bound}}
    (E / "verification.json").write_text(json.dumps(verification, indent=2) + "\n", encoding="utf-8")
    text = f'''# Cierre offline · Agentic Systems 2.1.4.dev8

Estado: **validación local offline pasada; release estable pendiente**.
No se abrió PR, no se ejecutó CI remota, no se publicó y no hubo inferencia.
El árbol conserva trabajo previo sin commit; el commit base no representa por
sí solo estos cambios. [Fuentes y artefactos](delivery-build07/manifest.json) ·
[Vinculación de la evidencia](verification.json) · [Resumen](summary.json).

## Áreas de cierre

| Área | Resultado verificable | Límite |
|---|---|---|
| Source | Graph común, compile, Context/Memory, plazos, eventos y sesión AWS; 469 regresiones contra fuente | Python 3.14.2 local |
| API | 15 palabras propias y cinco objetos originales de LangGraph; firmas desde la instalación | Sin aliases de APIs anteriores; no se certifican todos los parámetros por mencionar una palabra |
| Tutorials | 22 notebooks en kernels nuevos | Solo perfil offline |
| Examples | Ocho notebooks y 58 entrypoints; 34 experimentos históricos adaptados conservan sus antecedentes | MCP/A2A mantiene perfil separado dev7; no se transfirió aceptación |
| Documentación y skill | Índices, estados, firmas, RunResults/Memory/linaje y skill dev8 alineados | Comprensión por usuarios nuevos aún no medida |
| CLI y scaffolder | Proyecto externo con espacios: app, example, tests, notebook y tres actores Python | doctor comprueba dependencias, no servicios |
| Pytests y calidad | 469 PASS instaladas, cero fallos/omisiones; Ruff, tres contratos de arquitectura y secretos | Cobertura de sentencias del núcleo 100%; motor privado y plantillas excluidos por política existente |

Pyright estricto: **nueve archivos actuales de esquemas/normalización, cero errores**.
El perfil antiguo apuntaba a módulos retirados y dos scripts históricos (225
diagnósticos); se conserva como antecedente y se migró a sus contratos vigentes.
No se afirma tipado estricto de toda la fachada ni de todos los SDK externos.
La primera prueba exploratoria usó rutas de configuración incorrectas y analizó
copias de staging; su salida no se considera diagnóstico de la candidata.

La suite genera 14 advertencias de dependencias/harness, conservadas en logs.
Los notebooks omiten **{skipped} celdas live/local**, detalladas por archivo.
Los tres actores (native, OpenAI Agents y Strands) se ejecutan con Python
determinista. Las fixtures de transporte no prueban razonamiento ni IAM real.

La skill también pasó su [prueba funcional](skill-validation.json): ejemplo
integrado, scaffolder y tests del proyecto generado. Se corrigió la duplicación
de tests y de configuración pytest; el SDK conserva exactamente el mismo wheel.

## Artefactos

Wheel SDK probado: `{installation['wheel_sha256']}`.
Se verificaron 122 hashes RECORD y 117 archivos de paquete coincidentes entre
fuente, instalación, wheel y sdist. SDK, Studio y ADA pasaron Twine estricto.
Los artefactos anteriores y los intentos fallidos de construcción se conservan.
Build06 falló por permisos del sandbox de pip; build07 se construyó offline en
su directorio nuevo. No se reemplazó ningún archivo publicado.

Los artefactos están en [delivery-build07/dist](delivery-build07/dist/).
El manifiesto de construcción necesita este verification.json: no equivale a
un manifiesto certificado de publicación. La matriz de Actions está preparada
para construir una vez y usar esos bytes en Python 3.10–3.14; aún no se ejecutó.

## AWS/ADA y antecedentes

En 2.1.0–2.1.2 existían snapshots/diagnóstico y reparación de la cadena AWS.
Bedrock construía una Session y Strands recibía esa misma sesión. No había
extra ada ni inyección pública de una sesión externa. La reparación global
del entorno no se trasladó automáticamente.

Dev8 añade session= al runtime Bedrock, sin otro constructor. Selecciona IAM,
rechaza conflictos, mantiene la sesión fuera de JSON/Context/Memory y no la
cierra. Las invocaciones que comparten el recurso se serializan dentro del
toolkit, sujetas al plazo; no se promete coordinación con usos externos.
El SDK ya no modifica IMDS globalmente. El paquete independiente ADA aporta
diagnóstico sin resolver credenciales ni llamar a STS/IMDS; no va incluido en all.
AWS IAM, ADA IAM y ADA Studio/wallet siguen pendientes.

## Evidencia de uso

[Inventario exhaustivo de notebooks](../../../docs/NOTEBOOK_INVENTORY_214.md) ·
[RunResults, human_results, Memory y linaje por archivo](../../../docs/RUNRESULTS_LINEAGE_214.md) ·
[API y firmas](../../../docs/API_214_SURFACE.md) ·
[Notebook de linaje que cambia decisiones](../../../examples/lineage_memory/01_lineage_memory_decisions.ipynb) ·
[Notebook de sesión AWS](../../../examples/aws_session/01_aws_session.ipynb).

## Antes de publicar

1. Revisar el diff final y preparar el PR, seleccionando fuentes/evidencia útiles;
   no añadir caches, backups ni todas las copias de staging al repositorio.
2. Exigir CI real en Python 3.10–3.14, incluido el análisis estricto migrado.
3. Acordar campaña online para este wheel. Ningún PASS live anterior se transfiere.
   Permanecen abiertos Bedrock/Qwen con amount:null, interoperabilidad Ollama
   cloud y Studio/Bedrock; consultar los casos originales, sin inventar valores.
4. Mantener vLLM GPU y AWS/ADA IAM pendientes hasta disponer de sus entornos.
   Repetir MCP/A2A y los controles Studio acordados para ampliar la aceptación.
5. Revisar numeración y notas de ruptura respecto a 2.1.3, congelar la candidata
   estable y promover sus mismos bytes por TestPyPI, PyPI y GitHub cuando se autorice.

Memory y continuaciones son locales al proceso: no hay recuperación durable,
rollback general ni API RL completa. No se presentan como implementados.
La campaña dev5 permanece intacta: 148/150 solicitudes y USD 0.875040 reservados;
quedan dos solicitudes, insuficientes para prometer la aceptación online completa.
'''
    (E / "REPORT.md").write_text(text, encoding="utf-8")
    print(json.dumps({"wheel_sha256": installation["wheel_sha256"], "tests": 469, "notebooks": 30, "examples": 58, "skipped_notebook_cells": skipped, "offline_passed": True, "live_passed": False}))


if __name__ == "__main__":
    main()
