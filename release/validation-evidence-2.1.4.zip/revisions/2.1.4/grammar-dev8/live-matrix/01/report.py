"""Reconcile preserved profiles and the final ledger; never send inference."""
from decimal import Decimal
import hashlib
import json
from pathlib import Path

E = Path(__file__).resolve().parent
ROOT = E.parents[4]


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    plan = read(E / "plan.json")
    base_file = sorted((E / "runs").glob("*/results.json"))[-1]
    follow_file = sorted((E / "required-policy-runs").glob("*/results.json"))[-1]
    base = read(base_file)["rows"]
    follow = read(follow_file)["rows"]
    assert len(base) == 36 and len(follow) == 3
    assert sha(E / "challenge.py") == plan["challenge_sha256"]
    assert sha(E / "run.py") == plan["worker_sha256"]
    assert all(row["passed"] for row in base if row["case"] in {"pilot", "negatives"})
    ledger = read(E / "campaign-budget.json")
    total = sum((Decimal(row["reserved_usd"]) for row in ledger["attempts"]), Decimal(0))
    requests = len(ledger["attempts"])
    metadata = sum(row.get("kind") == "metadata" for row in ledger["attempts"])
    assert requests <= 300 and total <= 10
    assert [row["attempt"] for row in ledger["attempts"]] == list(range(1, requests + 1))
    assert all(row["max_output_tokens"] == 1024 for row in ledger["attempts"] if row.get("kind") != "metadata")
    assert sha(ROOT / "revisions/2.1.4/contracts-dev5/campaign-budget.json") == "6ce1ae54e97e11835598312e56ca403ca7b267478a99ce1bc5c93a0bdbd5b9e6"
    original = {(row["route"], row["framework"]): row for row in base if row["case"] == "composition"}
    required = {row["framework"]: row for row in follow}
    matrix = []
    for route in plan["routes"]:
        cells = {}
        for framework in plan["frameworks"]:
            row = original[(route, framework)]
            choice = "auto"
            if not row["passed"] and route == "bedrock-runtime" and required[framework]["passed"]:
                row, choice = required[framework], "required"
            cells[framework] = {"passed": row["passed"], "tool_choice": choice,
                                "original_auto_passed": original[(route, framework)]["passed"]}
        matrix.append({"route": route, "model": plan["routes"][route]["model"], "cells": cells})
    qualified = sum(cell["passed"] for row in matrix for cell in row["cells"].values())
    late = sum(row["budget_after_process_exit"]["attempts"] - row["budget_after_worker_snapshot"]["attempts"]
               for row in [*base, *follow] if "budget_after_worker_snapshot" in row)
    summary = {"version": plan["version"], "wheel_sha256": plan["wheel_sha256"], "base_auto_passed": sum(row["passed"] for row in original.values()),
               "base_auto_total": 12, "followup_required_bedrock_passed": sum(row["passed"] for row in follow),
               "followup_required_bedrock_total": 3, "qualified_configurations_passed": qualified,
               "matrix": matrix, "generation_pilots_passed": 12, "negative_profiles_passed": 12,
               "requests": requests, "inference_requests": requests - metadata, "metadata_requests": metadata,
               "reserved_usd": str(total), "remaining_requests": 300 - requests, "remaining_usd": str(Decimal(10) - total),
               "late_dispatches_after_worker_snapshot": late, "full_acceptance": False, "published": False,
               "blocker": "Strands Bedrock adapter does not forward policy.tool_choice=required: offline capture observes auto instead of any.",
               "base_evidence": base_file.relative_to(ROOT).as_posix(), "followup_evidence": follow_file.relative_to(ROOT).as_posix()}
    (E / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = ["# Matriz online · Agentic Systems 2.1.4.dev8", "",
             f"Resultado: **{qualified}/12 combinaciones funcionales en las configuraciones documentadas; aceptación completa bloqueada**.", "",
             "No se cambió el SDK ni se publicó. Se usó el wheel instalado fuera del checkout: " + plan["wheel_sha256"] + ".",
             "", "## Matriz de configuración validada", "", "| Runtime / modelo | native | openai-agents | strands |", "|---|---|---|---|"]
    for row in matrix:
        labels = [("PASS · " + cell["tool_choice"]) if cell["passed"] else "FAIL · auto y required" for cell in row["cells"].values()]
        lines.append("| " + row["route"] + " / " + row["model"] + " | " + " | ".join(labels) + " |")
    lines += ["", "**El perfil original auto pasó 9/12.** Bedrock falló en los tres frameworks por omitir audit_payment. El seguimiento cambió exclusivamente policy.tool_choice a required en los dos actores con Tools: pasaron native y OpenAI Agents; Strands siguió fallando. No se atribuye ese seguimiento al perfil auto ni se borran sus fallos.", "",
              "Los 12 pilotos de generación JSON y los 12 perfiles negativos pasaron. Cada perfil negativo verifica entrada inválida y fallo de Tool antes del actor; consumió cero inferencia. La identidad del framework aparece en framework_adapter dentro de los RunResults guardados.", "",
              "## Input → proceso → output", "",
              "- System: SINGLE, amount=15000 → fee=150 → decision=review, status=pending_review.",
              "- Environment: PAY-001, amount=5000, dos episodios → fee=50; primero approve, después review_duplicate por Memory. Estado final: processed=2, approved=1, reward=1. Reward es un agregado del ejemplo, no una API RL pública.",
              "- Eval: EVAL-001, amount=5000, dos casos → approve en ambos, cada uno con una copia de la misma Memory previa; la Memory externa permanece idéntica. Aislar no equivale a vaciar Memory.",
              "- Agent con Graph: validación determinista → actor de comisiones. Otro Agent con Graph ejecuta el actor auditor. El System coordina ambos y enruta la decisión; el Environment tiene su propio Graph.",
              "- Tools Pydantic y Skills, Context con fuentes, linaje previo obligatorio, Memory, decisiones, serialización e invariantes. El estado conserva solo campos de negocio. Eval usa oráculos deterministas; no un juez LM.", "",
              "Cada combinación completa comprueba una ejecución de System, dos episodios y dos casos de Eval. Los actores usan modelos reales para invocar Tools y producir JSON; las operaciones y reglas financieras siguen en las Tools deterministas. No se prueba razonamiento abierto o toda la superficie de los SDK.", "",
              "## Defecto confirmado", "",
              "[La captura offline](strands-policy-offline-proof.json) reproduce en el SDK instalado que policy.tool_choice=required llega a Bedrock como toolChoice.auto. Al proporcionar any directamente al stream del SDK, el request conserva any. No hubo red ni credenciales reales en esa prueba.",
              "El hueco está entre _configure_model y ContractAwareBedrockModel.stream del adaptador Strands: la configuración plana de Bedrock solo recibe parámetros de generación; el selector requerido no se traslada. El servicio devolvió HTTP 200/end_turn y una decisión plausible sin invocar audit_payment; el contrato rechazó esa salida correctamente.",
              "Corrección pendiente: trasladar la política al selector por turno, liberar la obligación después de satisfacer el contrato y conservar max_tool_calls y la continuación. Añadir regresiones para required/auto/none y generar otro wheel; después repetir la aceptación correspondiente. No se aplicó un bypass al wheel probado.", "",
              "## Consumo y evidencia", "",
              f"{requests}/300 solicitudes totales: {requests-metadata} de inferencia y {metadata} de metadatos. Reserva conservadora USD {total}/10; quedan {300-requests} solicitudes y USD {Decimal(10)-total}. No es una factura ni se devolvieron reservas por fallos. El contador anterior permanece intacto.",
              f"Despachos observados después del snapshot del trabajador: {late}. El padre leyó el contador tras la salida de cada proceso; los hooks siguieron instalados mientras terminaban los trabajadores. No se promete preempción de una llamada remota.",
              "La reserva de OpenAI usa las [tarifas oficiales del modelo](https://developers.openai.com/api/docs/models/gpt-4.1-mini). Para Bedrock y Ollama cloud se reservaron USD1/4 por millón de tokens de entrada/salida como techo de seguridad, contrastado con [AWS](https://aws.amazon.com/bedrock/pricing/) y [Ollama](https://ollama.com/pricing). Cada byte UTF-8 más framing se reserva como token de entrada, con salida máxima y margen del 25%; no se descuentan cachés.",
              "Ollama local registró el Qwen con 3180247121 bytes de VRAM en [api/ps](gpu-observation.json). Ollama cloud resolvió gemma4:31b-cloud al slug gemma4:31b del mismo modelo, antes de congelar casos; no se sustituyó por otro modelo.", "",
              "[Perfil y casos congelados](plan.json) · [Challenge visible](challenge.py) · [Seguimiento required](required-policy-plan.json) · [Contador](campaign-budget.json) · [Resumen](summary.json).", "",
              "Cada JSON de trabajador conserva RunResults, Context recibidos, Memory antes/después de Eval, human_results y linaje. Los resultados originales están en " + base_file.parent.relative_to(E).as_posix() + "; el seguimiento separado está en " + follow_file.parent.relative_to(E).as_posix() + ".", "",
              "## Pendientes", "",
              "Strands + Bedrock sigue bloqueado. El caso antiguo amount:null no se repitió aquí, ni el System mixto de tres frameworks: supplement.py quedó preparado, sin ejecutarse. Tampoco se validan handoffs, MCP/A2A, toda la UI Studio, AWS/ADA IAM ni vLLM/GPU con esta campaña. No se amplía su aceptación por inferencia.",
              "Con seis solicitudes no alcanza para repetir la matriz completa contra otro wheel. Se conserva el saldo y no se publica ni se declara certificación completa."]
    (E / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    files = [p for p in E.rglob("*") if p.is_file() and p.suffix in {".py", ".json", ".md"}
             and "__pycache__" not in p.parts and p.name != "evidence-manifest.json"]
    manifest = {"version": plan["version"], "wheel_sha256": plan["wheel_sha256"], "status": "incomplete-live-acceptance",
                "files_sha256": {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted(files)}}
    (E / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: summary[key] for key in ("base_auto_passed", "qualified_configurations_passed", "requests", "inference_requests", "metadata_requests", "reserved_usd", "remaining_requests", "full_acceptance")}))


if __name__ == "__main__":
    main()
