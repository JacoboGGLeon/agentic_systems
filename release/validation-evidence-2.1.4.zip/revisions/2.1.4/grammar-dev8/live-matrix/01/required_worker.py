"""Bedrock follow-up: explicitly require the Tool, preserving the original failures."""
import argparse
import os
from pathlib import Path
import sys
import time

from run import E, ROOT, read, write, digest, secrets, serialize, ledger_summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("framework", choices=("native", "openai-agents", "strands"))
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    plan = read(E / "plan.json")
    followup = read(E / "required-policy-plan.json")
    install = read(ROOT / "revisions/2.1.4/grammar-dev8/installation.json")
    assert digest(E / "challenge_required.py") == followup["required_challenge_sha256"]
    assert digest(E / "challenge.py") == followup["original_challenge_sha256"]
    assert digest(ROOT / install["wheel"]) == plan["wheel_sha256"]
    sys.path[:0] = [install["site"], str(E)]
    values, _ = secrets()
    spec = plan["routes"]["bedrock-runtime"]
    key = values[spec["key_env"]]
    os.environ.update(OPENAI_AGENTS_DISABLE_TRACING="1", OTEL_SDK_DISABLED="true", LANGSMITH_TRACING="false",
        AWS_EC2_METADATA_DISABLED="true", AGENTIC_BUDGET_FILE=str(E / "campaign-budget.json"),
        AWS_BEARER_TOKEN_BEDROCK=key, AWS_REGION=spec["region"], AWS_DEFAULT_REGION=spec["region"])
    import agentic_systems as toolkit
    from agentic_systems_studio.budget import ensure_budget
    import challenge_required
    budget = ensure_budget()
    budget.phase = "policy-required/bedrock-runtime/" + args.framework
    row = {"route": "bedrock-runtime", "framework": args.framework, "case": "composition-required-policy",
        "model": spec["model"], "wheel_sha256": plan["wheel_sha256"], "policy": {"tool_choice": "required"},
        "budget_before": ledger_summary(), "passed": False}
    started = time.monotonic()
    try:
        connection = toolkit.runtime(provider="bedrock-runtime", model=spec["model"], endpoint=spec["endpoint"],
            region=spec["region"], api_key=key, timeout_s=90, max_tokens=1024, max_turns=3, max_tool_calls=1, max_retries=0)
        evidence = challenge_required.composition(connection, args.framework)
        row.update(evidence=serialize(evidence, toolkit), passed=all(evidence["checks"].values()))
    except Exception as exc:
        row["error"] = {"type": type(exc).__name__, "message": str(exc)[-4000:]}
    row.update(elapsed_s=round(time.monotonic() - started, 3), budget_after_worker_snapshot=ledger_summary())
    write(args.output, row)
    return 0 if row["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
