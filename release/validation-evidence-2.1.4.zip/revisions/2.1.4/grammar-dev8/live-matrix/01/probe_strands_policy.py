"""Capture the installed adapter-to-SDK request offline; no inference or credentials."""
import asyncio
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

E = Path(__file__).resolve().parent
ROOT = E.parents[4]
install = json.loads((ROOT / "revisions/2.1.4/grammar-dev8/installation.json").read_text(encoding="utf-8"))
sys.path[:0] = [install["site"], str(ROOT / "tutorials")]
os.environ.update(OTEL_SDK_DISABLED="true", OPENAI_AGENTS_DISABLE_TRACING="1", AWS_EC2_METADATA_DISABLED="true")
from _offline import enforce_offline, blocked_attempts  # noqa: E402
enforce_offline()

import boto3  # noqa: E402
from strands.models import BedrockModel  # noqa: E402
from agentic_systems._engine.contracts import RunPolicy  # noqa: E402
from agentic_systems._engine.integrations.adapters.strands import _materialize_model, _configure_model  # noqa: E402

captured = []
original = BedrockModel.stream


async def capture(self, messages, tool_specs=None, system_prompt=None, *, tool_choice=None, **kwargs):
    request = self.format_request(messages, tool_specs=tool_specs,
                                  system_prompt_content=[{"text": system_prompt}] if system_prompt else None,
                                  tool_choice=tool_choice)
    captured.append({"sdk_stream_choice": tool_choice, "bedrock_request_choice": request.get("toolConfig", {}).get("toolChoice")})
    if False:
        yield None


async def main():
    # Synthetic explicit credentials avoid resolving any user/environment chain.
    session = boto3.Session(aws_access_key_id="testing", aws_secret_access_key="testing", region_name="us-east-2")
    actor = SimpleNamespace(engine="bedrock-runtime", model="qwen.qwen3-32b-v1:0",
        runtime_config=SimpleNamespace(region_name="us-east-2"),
        contract=SimpleNamespace(completion="always_finalize", must_call=("audit_payment",), tool_expectation=None))
    engine = SimpleNamespace(session=session, auth_mode="aws-credential-chain", streaming=False)
    BedrockModel.stream = capture
    try:
        model = _materialize_model(actor, engine)
        _configure_model(model, RunPolicy(tool_choice="required", max_tokens=1024, max_tool_calls=1), "default")
        messages = [{"role": "user", "content": [{"text": "Audit the supplied payment"}]}]
        tools = [{"name": "audit_payment", "description": "Audit", "inputSchema": {"json": {"type": "object", "properties": {}}}}]
        async for _ in model.stream(messages, tools, "Use the audit Tool"):
            pass
        async for _ in model.stream(messages, tools, "Use the audit Tool", tool_choice={"any": {}}):
            pass
    finally:
        BedrockModel.stream = original
    assert blocked_attempts() == 0
    assert captured[0]["bedrock_request_choice"] != {"any": {}}
    assert captured[1]["bedrock_request_choice"] == {"any": {}}
    result = {"version": install["version"], "wheel_sha256": install["wheel_sha256"],
              "requested_public_policy": "required", "captures": captured,
              "policy_translation_gap_reproduced": True, "sdk_supports_explicit_any": True,
              "network_requests": 0, "inference_requests": 0, "sdk_modified": False}
    (E / "strands-policy-offline-proof.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    asyncio.run(main())
