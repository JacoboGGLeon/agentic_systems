"""Reconcile current offline evidence; never execute a provider or old experiment."""

import json
from pathlib import Path

import agentic_systems as toolkit

ROOT = Path(__file__).resolve().parents[3]
E = Path(__file__).resolve().parent


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    assert toolkit.__version__ == "2.1.4.dev8"
    for name in ("API.md", "ARCHITECTURE.md", "CLI.md", "NARRATIVE_CONTRACT.md",
                 "QUALITY_GATES.md", "README.md", "RUNTIME_AND_FRAMEWORK_CONTRACTS.md",
                 "RELEASE_214.md", "LEARNING_PATH_214.md", "LEARNING_PLAN_214.md",
                 "GRAMMAR_COVERAGE_214.md"):
        path = ROOT / "docs" / name
        text = path.read_text(encoding="utf-8")
        for previous in ("2.1.4.dev5", "2.1.4.dev7", "grammar-dev7"):
            text = text.replace(previous, "grammar-dev8" if previous == "grammar-dev7" else "2.1.4.dev8")
        path.write_text(text, encoding="utf-8")
    path = ROOT / "tutorials/README.md"
    path.write_text(path.read_text(encoding="utf-8").replace("[Validación dev7]", "[Validación dev8]").replace("grammar-dev7/REPORT.md", "grammar-dev8/REPORT.md"), encoding="utf-8")
    for name in ("conceptual-model.md", "release-distribution.md"):
        path = ROOT / "skills/agentic-systems/references" / name
        path.write_text(path.read_text(encoding="utf-8").replace("dev7", "dev8"), encoding="utf-8")

    inventory = json.loads((ROOT / "docs/NOTEBOOK_INVENTORY_214.json").read_text(encoding="utf-8"))
    examples = json.loads((E / "closure/examples-offline.json").read_text(encoding="utf-8"))["rows"]
    destination = E / "closure/lineage"
    destination.mkdir(exist_ok=True)
    rows = []
    for row in inventory["notebooks"]:
        capture = json.loads((ROOT / row["capture"]).read_text(encoding="utf-8"))
        rows.append((row["path"], capture["run_results"], capture["memories"], row["capture"], "offline-passed"))
    for row in examples:
        results = {str(index): value for index, value in enumerate(row.get("run_results", []))}
        rows.append((row["path"], results, {}, "revisions/2.1.4/grammar-dev8/closure/examples-offline.json", row["status"]))

    lines = ["# RunResults, linaje y Memory · 2.1.4.dev8", "",
             "Evidencia offline del wheel final instalado. Cada fila enlaza resultados guardados, human_results y linaje derivados de esos resultados; no se ejecuta inferencia al construir este informe.", "",
             "Un contador cero significa que el ejemplo no expuso un RunResult/Memory capturable, no que la librería haya inventado uno. Los casos negativos pueden contener resultados fallidos esperados. La Memory listada es la capturada explícitamente por el notebook; no es persistencia durable.", "",
             "| Archivo | RunResults capturados | Memory capturada | Perfil |", "|---|---:|---:|---|"]
    for source, raw, memories, origin, status in rows:
        rendered = {}
        for key, data in raw.items():
            result = toolkit.RunResult(**data)
            rendered[key] = {"run_result": data, "human_results": result.human_results(),
                             "lineage": result.lineage().to_dict(),
                             "agent_context": result.lineage().to_prompt_context()}
        filename = source.replace("/", "--") + ".json"
        target = destination / filename
        write_json(target, {"version": toolkit.__version__, "wheel_sha256": inventory["wheel_sha256"],
                            "source": source, "evidence": origin, "profile": status,
                            "results": rendered, "memories": memories, "inference_requests": 0})
        relative = target.relative_to(ROOT).as_posix()
        lines.append(f"| [{source}](../{source}) | [{len(rendered)}](../{relative}) | {len(memories)} | {status} |")
    lines += ["", "MCP/A2A no se repitió en dev8: su perfil local dev7 sigue como antecedente. Las celdas live/local omitidas están en el [inventario](NOTEBOOK_INVENTORY_214.md). [Resumen](../revisions/2.1.4/grammar-dev8/summary.json)."]
    (ROOT / "docs/RUNRESULTS_LINEAGE_214.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"files": len(rows), "inference_requests": 0}))


if __name__ == "__main__":
    main()
