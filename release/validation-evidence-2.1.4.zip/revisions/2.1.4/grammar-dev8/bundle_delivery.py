"""Package current learning material/evidence and skill without secrets/history."""

import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[3]
E = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
from check_secrets import PATTERNS, PLACEHOLDERS, _local_secret_values  # noqa: E402


def main():
    assets = E / "delivery-build07"
    bundles = assets / "bundles-final"
    bundles.mkdir()
    summary = json.loads((E / "summary.json").read_text(encoding="utf-8"))
    assert summary["tests"]["failures"] == 0 and summary["notebooks"] == 30
    secrets = _local_secret_values()
    ignored = {"history", "evidence", "__pycache__", ".venv", "build", "dist", ".ipynb_checkpoints", ".pytest_cache", ".ruff_cache"}

    def allowed(path):
        return (path.is_file() and not (set(path.relative_to(ROOT).parts) & ignored)
                and not any(part.endswith(".egg-info") for part in path.parts)
                and path.suffix not in {".pyc", ".pyo"}
                and (not path.name.startswith(".env") or path.name == ".env.example"))

    files = []
    for directory in (ROOT / "tutorials", ROOT / "examples"):
        files += [p for p in directory.rglob("*") if allowed(p)]
    files += [ROOT / name for name in ("README.md", "INSTALL.md", "LICENSE")]
    names = {"README.md", "API.md", "CLI.md", "ARCHITECTURE.md", "NARRATIVE_CONTRACT.md", "QUALITY_GATES.md",
             "API_CONTRACT.md", "RUNRESULT_CONTRACT.md", "RUNTIME_AND_FRAMEWORK_CONTRACTS.md", "CONTRIBUTING_CHECKLIST.md"}
    files += [p for p in (ROOT / "docs").glob("*.md") if "214" in p.name or p.name in names]
    files += [ROOT / "docs/NOTEBOOK_INVENTORY_214.json"]
    files += [p for p in (ROOT / "docs/assets").rglob("*") if allowed(p)]
    files += [p for p in (ROOT / "integrations/ada").rglob("*") if allowed(p)]
    files += [ROOT / "scripts" / name for name in ("validate_learning_offline_214.py", "validate_learning_notebooks_214.py", "grammar_coverage_214.py", "validate_scaffold.py", "check_catalog.py")]
    files += [E / name for name in ("REPORT.md", "summary.json", "verification.json", "installation.json", "api.json",
              "installed-suite-closure.xml", "source-suite-closure.xml", "installed-coverage-closure.json", "pyright-final.json", "integrity-build07.json", "skill-validation.json", "skill-generated-tests.xml")]
    latest = sorted((E / "closure/notebook-runs").glob("*/results.json"))[-1].parent
    files += [p for p in latest.iterdir() if p.is_file()]
    files += [p for p in (E / "closure/examples").glob("*.json")]
    files += [p for p in (E / "closure/lineage").glob("*.json")]
    files += [E / "closure/examples-offline.json", E / "closure/scaffolder-build07/scaffolder.json", E / "closure/scaffolder-build07/scaffold-executed.ipynb", assets / "manifest.json"]
    files += list((assets / "dist").iterdir())
    hashes = {}

    def bundle(path, sources, prefix, readme=None):
        if path.exists():
            raise FileExistsError("Preserve the previous bundle")
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            if readme:
                archive.writestr(prefix + "/README_BUNDLE.md", readme)
            for source in sorted(set(sources)):
                payload = source.read_bytes()
                low = payload.lower()
                if any(secret in payload for secret in secrets) or (any(pattern.search(payload) for pattern in PATTERNS) and not any(marker in low for marker in PLACEHOLDERS)):
                    raise ValueError("Secret gate rejected " + source.relative_to(ROOT).as_posix())
                name = source.relative_to(ROOT).as_posix()
                if source.is_relative_to(ROOT / "skills/agentic-systems"):
                    name = source.relative_to(ROOT / "skills/agentic-systems").as_posix()
                archive.writestr(prefix + "/" + name, payload)
                hashes[source.relative_to(ROOT).as_posix()] = hashlib.sha256(payload).hexdigest()
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
        return {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size}

    readme = """# Material de aprendizaje · Agentic Systems 2.1.4.dev8

Descomprime esta carpeta y sigue INSTALL.md. Incluye los mismos wheels locales
probados, tutorials/, examples/, documentación y evidencia offline. No incluye
dependencias transitivas: pip necesita acceso a sus paquetes o una caché propia.
Usa el kernel del entorno donde instalaste el SDK. La revisión no está publicada.

Empieza por tutorials/core/00_start.ipynb y continúa en tutorials/README.md.
Los resultados visibles están ejecutados. Las celdas live/local omitidas no se
certifican y pueden consumir inferencia al ejecutarlas manualmente. Consulta
revisions/2.1.4/grammar-dev8/REPORT.md antes de pruebas con proveedores.

La skill se entrega también en un ZIP independiente. El bundle omite historia,
backups, staging y evidencia antigua de Studio; los enlaces históricos remiten
al checkout original. No contiene claves ni .env. El wheel por sí solo no
materializa tutorials/examples. No hay publicación ni certificación online.
"""
    outputs = {}
    path = bundles / "agentic-systems-learning-2.1.4.dev8-build07.zip"
    outputs["bundles-final/" + path.name] = bundle(path, files, "agentic-systems-learning-2.1.4.dev8", readme)
    skill_files = [p for p in (ROOT / "skills/agentic-systems").rglob("*") if allowed(p)]
    path = bundles / "agentic-systems-skill-2.1.4.dev8.zip"
    outputs["bundles-final/" + path.name] = bundle(path, skill_files, "agentic-systems")
    for path in sorted((assets / "dist").iterdir()):
        outputs["dist/" + path.name] = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size}
    manifest = {"version": summary["version"], "wheel_sha256": summary["wheel_sha256"],
                "status": "local-offline-delivery-not-published", "artifacts": outputs, "bundled_source_sha256": hashes,
                "inference_requests": 0, "remote_ci": "pending", "live_acceptance": "pending"}
    (assets / "assets-manifest-final.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"artifacts": outputs, "bundled_files": len(hashes)}, indent=2))


if __name__ == "__main__":
    main()
