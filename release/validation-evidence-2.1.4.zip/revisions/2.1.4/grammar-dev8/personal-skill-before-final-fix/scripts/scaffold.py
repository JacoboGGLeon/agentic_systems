"""Generate with the installed dev7 CLI; add and execute a business test separately."""

import argparse
import hashlib
import json
from pathlib import Path
import agentic_systems as toolkit
from agentic_systems.cli import main


def scaffold(destination):
    assert toolkit.__version__ == "2.1.4.dev8", "Install the local dev7 wheel first"
    path = Path(destination).resolve()
    if path.exists():
        raise FileExistsError(path)
    main(["new", str(path)])
    (path / "tests").mkdir()
    (path / "tests/test_contract.py").write_text(
        "from order_fulfillment.application import demonstrate\ndef test_refund():\n    report = demonstrate()\n    assert report['output']['refund'] == 120\n",
        encoding="utf-8",
    )
    project = path / "pyproject.toml"
    project.write_text(
        project.read_text(encoding="utf-8")
        + '\n[tool.pytest.ini_options]\npythonpath = ["src"]\n',
        encoding="utf-8",
    )
    manifest = path / "manifest.json"
    metadata = json.loads(manifest.read_text(encoding="utf-8"))
    metadata["skill_version"] = "2.1.4.dev8"
    manifest.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    files = sorted(
        p for p in path.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt"
    )
    (path / "SHA256SUMS.txt").write_text(
        "".join(
            hashlib.sha256(p.read_bytes()).hexdigest()
            + "  "
            + p.relative_to(path).as_posix()
            + "\n"
            for p in files
        ),
        encoding="utf-8",
    )
    return path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination")
    print(scaffold(parser.parse_args().destination))
