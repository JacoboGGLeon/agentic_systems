"""Assemble local dev8 delivery, retaining the exact wheel already tested."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[3]
E = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    destination = E / "delivery-build07"
    if destination.exists():
        raise FileExistsError("Preserve earlier deliveries; choose a new destination")
    stage = destination / "source"
    dist = destination / "dist"
    stage.mkdir(parents=True)
    dist.mkdir()
    shutil.copytree(ROOT / "src", stage / "src", ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.egg-info"))
    for name in ("pyproject.toml", "README.md", "CHANGELOG.md", "LICENSE", "MANIFEST.in"):
        shutil.copyfile(ROOT / name, stage / name)
    installation = json.loads((E / "installation.json").read_text(encoding="utf-8"))
    wheels = {Path(installation["wheel"]).name: installation["wheel_sha256"], **installation["applications"]}
    for filename, digest in wheels.items():
        source = ROOT / installation["wheel"] if filename == Path(installation["wheel"]).name else E / "builds/05/dist" / filename
        assert sha(source) == digest
        shutil.copyfile(source, dist / filename)
    # Test profile/changelog changed after earlier builds, but wheel payload did not.
    # Rebuild only source distribution; never replace the tested SDK wheel.
    result = subprocess.run([sys.executable, "-c", "import setuptools.build_meta as b; b.build_sdist(" + repr(str(dist)) + ")"],
                            cwd=stage, capture_output=True, text=True, encoding="utf-8")
    (destination / "sdist-build.log").write_text(result.stdout + result.stderr, encoding="utf-8")
    result.check_returncode()
    sdist = next(dist.glob("*.tar.gz"))
    checked = 0
    with tarfile.open(sdist) as archive:
        members = {"/".join(member.name.split("/")[1:]): member for member in archive.getmembers() if member.isfile()}
        for name in ("pyproject.toml", "README.md", "CHANGELOG.md", "LICENSE", "MANIFEST.in"):
            assert archive.extractfile(members[name]).read() == (ROOT / name).read_bytes(), name
        with zipfile.ZipFile(dist / Path(installation["wheel"]).name) as wheel:
            for name in wheel.namelist():
                if name.startswith("agentic_systems/") and not name.endswith("/"):
                    content = wheel.read(name)
                    assert content == (ROOT / "src" / name).read_bytes(), name
                    assert content == archive.extractfile(members["src/" + name]).read(), name
                    checked += 1
    sources = [p for p in (ROOT / "src").rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix not in (".pyc", ".pyo")]
    sources += [ROOT / name for name in ("pyproject.toml", "README.md", "CHANGELOG.md", "LICENSE", "MANIFEST.in")]
    manifest = {"version": "2.1.4.dev8", "status": "local-offline-delivery-not-a-certified-release",
                "base_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
                "working_tree_dirty": True, "inference_requests": 0, "published": False,
                "wheel_sha256": installation["wheel_sha256"], "sdist_wheel_payload_files_matched": checked,
                "artifacts": {p.name: sha(p) for p in sorted(dist.iterdir())},
                "source_sha256": {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted(sources)},
                "acceptance": {"local_offline": "requires-matching-summary-and-verification", "remote_ci": "pending", "live": "pending"}}
    (destination / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: manifest[key] for key in ("version", "wheel_sha256", "sdist_wheel_payload_files_matched", "acceptance")}))


if __name__ == "__main__":
    main()
