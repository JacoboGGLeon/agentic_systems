"""Compare business projections, retaining distinct execution IDs and traces."""
from pathlib import Path
import json
import sys
import hashlib

E = Path(__file__).resolve().parent
ROOT = E.parents[3]
sys.path.insert(0, str(ROOT / "scripts"))
from check_secrets import _local_secret_values  # noqa: E402

latest = {}
for path in sorted(E.glob("*/result.json")):
    row = json.loads(path.read_text(encoding="utf-8"))
    if row["passed"]:
        latest[row["profile"]] = (path, row)
assert set(latest) == {"python", "mixed"}
evidence = {key: json.loads((path.parent / "evidence.json").read_text(encoding="utf-8")) for key, (path, _) in latest.items()}
assert latest["python"][1]["source_sha256"] == latest["mixed"][1]["source_sha256"]


def business(value):
    results = value["run_results"]
    return {"single": results[0]["data"], "episodes": results[1]["data"]["outputs"],
            "environment_state": results[1]["data"]["summary"]["state"],
            "eval": {key: results[2]["data"][key] for key in ("total", "passed", "failed")}}


assert business(evidence["python"]) == business(evidence["mixed"])


def walk(node):
    yield node
    for child in node.get("children", []):
        yield from walk(child)


observed = sorted({(node.get("engine"), node.get("model"), node.get("meta", {}).get("framework_adapter"))
                   for result in evidence["mixed"]["run_results"] for node in walk(result) if node.get("model")}, key=str)
assert {"native", "strands", "openai-agents"}.issubset({row[2] for row in observed})
secrets = _local_secret_values()
paths = [*E.rglob("*"), *(ROOT / "examples/financial_mixed").glob("*")]
checked = 0
for path in paths:
    if not path.is_file() or path.suffix == ".pyc":
        continue
    assert not any(secret in path.read_bytes() for secret in secrets), path
    checked += 1
summary = {"profiles": {key: {**row, "path": str(path.relative_to(ROOT))} for key, (path, row) in latest.items()},
           "business_results_equal": True, "business": business(evidence["mixed"]),
           "contexts_per_profile": {key: len(value["contexts_received"]) for key, value in evidence.items()},
           "observed_runtime_model_framework": observed, "requests_this_task": 44,
           "budget_requests_total": 344, "budget_reserved_usd_total": "3.255425", "remaining_requests": 6,
           "secret_scan_files": checked, "sdk_modified": False, "published": False}
(E / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
manifest = {str(path.relative_to(ROOT)).replace("\\", "/"): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in paths if path.is_file() and path.name != "manifest.json" and path.suffix != ".pyc"}
(E / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"observed": observed, "business_results_equal": True, "files_scanned": checked}))
