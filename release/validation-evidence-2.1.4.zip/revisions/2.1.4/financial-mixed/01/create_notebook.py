"""Author the explicit lesson; no inference or execution at generation time."""
from pathlib import Path
import textwrap
import nbformat as nb

ROOT = Path(__file__).resolve().parents[4]
source = (ROOT / "revisions/2.1.4/problem-fixes/01/live/challenge.py").read_text()
cells = []


def md(text):
    cells.append(nb.v4.new_markdown_cell(textwrap.dedent(text).strip()))


def code(text):
    cells.append(nb.v4.new_code_cell(textwrap.dedent(text).strip()))


md('''# Pagos auditables: Python y un System de cuatro proveedores

API local **2.1.4.dev8**, wheel corregido. No es una versión asumida de PyPI.
La misma aplicación se ejecuta en dos perfiles: `python` y `mixed`.

Input: identificador e importe en centavos MXN. Proceso: validar → calcular
comisión → revisar política/linaje/duplicados → verificar local → verificar cloud
→ decidir ruta. Output: comisión, decisión y estado. No se transfieren fondos.

Los modelos seleccionan Tools; el dinero y las reglas se calculan con Python.
Todos los Agents y el System se orquestan con LangGraph. Environment añade
episodios/reward explícito y Eval comprueba resultados con Memory aislada.
Las credenciales y el medidor pertenecen al entorno de ejecución, nunca al estado.
''')
code('''import pydantic
import agentic_systems as toolkit

profile = globals().get("profile", "python")
assert profile in {"python", "mixed"}
assert toolkit.__version__ == "2.1.4.dev8"
print("API:", toolkit.__version__, "perfil:", profile)
''')
md('''## 1. Contratos de negocio

Pydantic declara los campos y rechaza tipos incorrectos/extra. Los campos
intermedios empiezan vacíos; los contratos finales exigen valores completos.
No se añaden defaults para reparar datos que debería proporcionar una Tool.
''')
code(source[source.index("class Payment"):source.index("def build(")])
md('''## 2. Runtime, scheduler, frameworks y proveedores

El runtime lleva plazo, reintentos y límites de turnos/Tools. No hay un constructor
Scheduler adicional. `framework` elige al actor; Graph siempre es LangGraph.

En Python los cuatro actores son deterministas. En mixed: comisión=OpenAI/native;
auditoría=Bedrock Qwen/Strands; verificación local=Ollama Qwen/Strands;
verificación final=Ollama cloud Gemma/OpenAI Agents. Se conservan los modelos
de la campaña previa. Los endpoints/modelos son configuración; no secretos.
''')
code('''if profile == "python":
    fee_runtime = toolkit.runtime(provider="python-runtime")
    audit_runtime = toolkit.runtime(provider="python-runtime")
    local_runtime = toolkit.runtime(provider="python-runtime")
    cloud_runtime = toolkit.runtime(provider="python-runtime")
else:
    # El runner prepara credenciales y activa presupuesto antes de esta celda.
    import os
    if not os.environ.get("AGENTIC_BUDGET_FILE"):
        raise RuntimeError("El perfil mixed requiere un contador autorizado activo")
    fee_runtime = toolkit.runtime(provider="openai-runtime", model="gpt-4.1-mini",
        timeout_s=90, max_turns=3, max_tool_calls=1, max_tokens=1024, max_retries=0)
    audit_runtime = toolkit.runtime(provider="bedrock-runtime", model="qwen.qwen3-32b-v1:0",
        region="us-east-2", timeout_s=90, max_turns=3, max_tool_calls=1, max_tokens=1024, max_retries=0)
    local_runtime = toolkit.runtime(provider="ollama-runtime", model="qwen3:4b-instruct-2507-q4_K_M",
        endpoint="http://127.0.0.1:11434/v1", api_key="ollama-local",
        timeout_s=90, max_turns=3, max_tool_calls=1, max_tokens=1024, max_retries=0)
    cloud_runtime = toolkit.runtime(provider="ollama-runtime", model="gemma4:31b",
        endpoint="https://ollama.com/v1",
        timeout_s=90, max_turns=3, max_tool_calls=1, max_tokens=1024, max_retries=0)

audit_framework = "strands" if profile == "mixed" else "native"
local_framework = "strands" if profile == "mixed" else "native"
cloud_framework = "openai-agents" if profile == "mixed" else "native"
print("Comisión: native; auditoría:", audit_framework,
      "; verificación local:", local_framework, "; final:", cloud_framework)
''')
md('''## 3. Context y Memory

Context aporta política y fuentes. Memory guarda dos episodios locales. El estado
del grafo solo contiene negocio; los Context y linajes se conservan aparte.
''')
body=textwrap.dedent(source[source.index("    received = []"):source.index("    fee_skill =")])
code(body.split("    @toolkit.tool")[0] if False else body[:body.index("@toolkit.tool")])
md('''## 4. Tools: funciones Pydantic, reglas explicables

El auditor exige linaje correcto del Agent `fees`. Si Memory contiene una aprobación
anterior del mismo pago, decide `review_duplicate`. Nunca duplica un cobro real.
''')
code(body[body.index("@toolkit.tool"):])
code('''@toolkit.tool(input_schema=DecisionOutput, output_schema=DecisionOutput)
def verify_local(request: DecisionOutput, *, context: toolkit.Context) -> DecisionOutput:
    """Check the current review evidence without changing business data."""
    received.append({"agent": "local", "input": request.model_dump(), "context": context.to_dict()})
    evidence = [row for row in context.lineage if row["name"] == "reviewer" and row["ok"]]
    if not evidence or evidence[-1]["data"] != request.model_dump():
        raise ValueError("The local verifier requires the observed reviewer result")
    return request

@toolkit.tool(input_schema=DecisionOutput, output_schema=DecisionOutput)
def verify_cloud(request: DecisionOutput, *, context: toolkit.Context) -> DecisionOutput:
    """Check local verification lineage and the exact integer fee."""
    received.append({"agent": "cloud", "input": request.model_dump(), "context": context.to_dict()})
    evidence = [row for row in context.lineage if row["name"] == "local_verifier" and row["ok"]]
    if not evidence or evidence[-1]["data"] != request.model_dump():
        raise ValueError("The cloud verifier requires local verification lineage")
    if request.fee != request.amount * context.data["fee_bps"] // 10000:
        raise ValueError("Incorrect fee")
    return request
''')
md('''## 5. Skills y Agents actores

Cada Skill declara una Tool e instrucciones; no oculta una secuencia.
El contrato exige observar esa Tool y conservar su JSON de negocio.
''')
actors=textwrap.dedent(source[source.index("    fee_skill ="):source.index("    def fee_step")])
actors=actors.replace('runtime=connection, framework=toolkit.framework(framework_name)', 'runtime=fee_runtime, framework=toolkit.framework("native")',1)
actors=actors.replace('runtime=connection, framework=toolkit.framework(framework_name)', 'runtime=audit_runtime, framework=toolkit.framework(audit_framework)',1)
actors=actors.replace('connection.provider', 'fee_runtime.provider',1).replace('connection.provider','audit_runtime.provider',1)
code(actors)
code('''local_skill = toolkit.skill(name="local_verification", tools=(verify_local,),
    instructions="Verify the exact observed payment review.")
cloud_skill = toolkit.skill(name="cloud_verification", tools=(verify_cloud,),
    instructions="Verify the exact local evidence and fee.")

local_verifier = toolkit.Agent("local_verifier", runtime=local_runtime,
    framework=toolkit.framework(local_framework), skills=(local_skill,),
    instructions="Call verify_local exactly once with the supplied fields unchanged. Return ONLY the Tool business JSON, without its envelope.",
    contract=contract("verify_local", DecisionOutput), policy={"repair": False})
cloud_verifier = toolkit.Agent("cloud_verifier", runtime=cloud_runtime,
    framework=toolkit.framework(cloud_framework), skills=(cloud_skill,),
    instructions="Call verify_cloud exactly once with the supplied fields unchanged. Return ONLY the Tool business JSON, without its envelope.",
    contract=contract("verify_cloud", DecisionOutput), policy={"repair": False})
''')
md('''## 6. Agents con Graph propio y System con decisión

El Agent `fees` valida antes de invocar su actor. `reviewer` organiza la auditoría.
El System coordina esos Agents y los dos verificadores. Su función de decisión
elige aprobación o revisión. Todos usan el mismo Graph de LangGraph.
''')
graphs=textwrap.dedent(source[source.index("    def fee_step"):source.index("    episode_graph =")])
graphs=graphs.replace('graph.add_node("approve", approve)', '''graph.add_node("local_verifier", local_step)
graph.add_node("cloud_verifier", cloud_step)
graph.add_node("approve", approve)''')
graphs=graphs.replace('graph.add_conditional_edges("reviewer", choose_next, ["approve", "review"])', '''graph.add_edge("reviewer", "local_verifier")
graph.add_edge("local_verifier", "cloud_verifier")
graph.add_conditional_edges("cloud_verifier", choose_next, ["approve", "review"])''')
code('''def local_step(state: Payment):
    payload = {"payment_id": state.payment_id, "amount": state.amount,
               "fee": state.fee, "decision": state.decision}
    return local_verifier.run(payload)

def cloud_step(state: Payment):
    payload = {"payment_id": state.payment_id, "amount": state.amount,
               "fee": state.fee, "decision": state.decision}
    return cloud_verifier.run(payload)
'''+graphs)
md('''## 7. compile prepara; run ejecuta: primera operación

Input: 15000 centavos. Proceso: comisión=150; total=15150 supera límite=10000.
Output esperado: revisión pendiente. Esta ejecución usa los cuatro actores.
''')
code('''program = system.compile()
single_input = {"payment_id": "SINGLE", "amount": 15000}
single = program.run(single_input, timeout_s=480)
print("INPUT:", single_input)
print("PROCESO: validar → comisión → auditoría → verificación local/cloud → decisión")
print("OUTPUT:", single.data)
print(single.human_results())
assert single.ok, single.errors
assert single.data == {**single_input, "fee": 150, "decision": "review", "status": "pending_review"}
''')
md('''## 8. Environment: dos episodios, Memory y recompensa

El mismo pago de 5000 centavos aparece dos veces: primero se aprueba;
después Memory obliga a revisarlo como duplicado. `update` calcula una recompensa
didáctica por aprobación; no hay entrenamiento RL ni reward= implícito.
''')
env=textwrap.dedent(source[source.index("    episode_graph ="):source.index("    def check_payment")])
code(env+'''\nepisodes = environment.compile().run(timeout_s=960)
print("INPUT:", [sample, sample])
print("PROCESO: dos episodios; la segunda auditoría consulta Memory")
print("OUTPUT:", episodes.data)
print(episodes.human_results())
assert episodes.ok, episodes.errors
assert [row["decision"] for row in episodes.data["outputs"]] == ["approve", "review_duplicate"]
assert episodes.data["summary"]["state"] == {"processed": 2, "approved": 1, "reward": 1}
''')
md('''## 9. Eval: casos independientes, misma aplicación

Dos casos idénticos con un identificador nuevo deben aprobarse ambos. Cada caso
hereda una copia aislada de la Memory inicial; no escribe en la Memory exterior.
Eval no aísla servicios externos y aquí no se transfieren fondos.
''')
evaluation=textwrap.dedent(source[source.index("    def check_payment"):source.index('    return {"system":')])
code(evaluation+'''\nbefore_eval = memory.read()
evaluated = evaluation.compile().run(timeout_s=960)
after_eval = memory.read()
print("INPUT: dos casos EVAL-001 independientes")
print("PROCESO: ejecutar → comprobar contrato/datos → aislar Memory por caso")
print("OUTPUT:", evaluated.data)
print(evaluated.human_results())
assert evaluated.ok and evaluated.data["passed"] == 2, evaluated.errors
assert before_eval == after_eval and len(after_eval) == 2
''')
md('''## 10. Qué recibió cada Tool en Context; linaje sin inflar State

La tabla resume los Context efectivamente recibidos. El ejemplo de auditoría
expone el Context completo; la captura conserva todos. El state mantiene solo
campos de PaymentOutput. Lineage es evidencia de trabajo, no razonamiento privado.
''')
code('''import json

for row in received:
    context = row["context"]
    print(row["agent"], row["input"]["payment_id"],
          "policy=", context["data"],
          "episodios=", len(context["episodes"]),
          "linaje=", [step["name"] for step in context["lineage"]])

review_context = next(row["context"] for row in received if row["agent"] == "reviewer")
print("CONTEXT EXACTO DEL PRIMER REVISOR:")
print(json.dumps(review_context, ensure_ascii=False, indent=2))

for result in (single, episodes, evaluated):
    print(result.lineage().render())
    assert result.check_invariants().ok
    assert toolkit.RunResult(**result.to_dict()).data == result.data

assert all(set(row) == set(PaymentOutput.model_fields) for row in episodes.data["outputs"])
evidence = {
    "profile": profile, "input": single_input,
    "run_results": [result.to_dict() for result in (single, episodes, evaluated)],
    "human_results": [result.human_results() for result in (single, episodes, evaluated)],
    "lineage": [result.lineage().to_dict() for result in (single, episodes, evaluated)],
    "contexts_received": received,
    "memory_before_eval": before_eval, "memory_after_eval": after_eval,
}
print("Comprobaciones completas:", profile)
''')
md('''## Alcance

Se demuestra una aplicación financiera didáctica, no un sistema bancario certificado.
Python y mixed deben conservar los mismos resultados de negocio; se conserva toda
la evidencia, incluidos fallos. No prueba la ruta nullable amount:null de Bedrock,
que continúa pendiente; este contrato exige un importe entero positivo.
GPU vLLM, IAM/ADA, handoffs, MCP/A2A y UI de Studio no son parte de este notebook.
''')
notebook=nb.v4.new_notebook(cells=cells, metadata={"kernelspec":{"display_name":"Python 3", "language":"python", "name":"python3"}})
destination=ROOT/"examples/financial_mixed/01_financial_system.ipynb"
destination.parent.mkdir(parents=True,exist_ok=True)
nb.write(notebook,destination)
print(destination)
