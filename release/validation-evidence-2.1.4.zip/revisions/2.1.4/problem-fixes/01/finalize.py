"""Summarize immutable attempts; attribute requests by phase, not overlapping windows."""
import hashlib
import json
from collections import Counter
from decimal import Decimal
from pathlib import Path
import xml.etree.ElementTree as ET

E = Path(__file__).resolve().parent
ROOT = E.parents[3]


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


ledger = read(E / "live/campaign-budget.json")
phases = Counter(item["phase"] for item in ledger["attempts"])
matrix = read(sorted((E / "live/runs").glob("*/results.json"))[-1])
extras = read(sorted((E / "live/extras").glob("*/results.json"))[-1])
rows = []
for row in matrix["rows"]:
    rows.append({key: row.get(key) for key in ("case", "route", "framework", "passed", "not_attempted")})
    rows[-1]["requests_attributed"] = phases[f"{row['route']}/{row['framework']}/{row['case']}"]
extra_rows = []
for row in extras["rows"]:
    phase = f"studio/bedrock/{row['framework']}" if row["case"] == "studio" else f"supplement/{row['case']}/{row['route']}/{row['framework']}"
    before = row.get("budget_before", {}).get("attempts", 0)
    after = row.get("budget_after_worker_snapshot", {}).get("attempts", len(ledger["attempts"]))
    attributed = sum(item["phase"] == phase for item in ledger["attempts"][before:after])
    extra_rows.append({**{key: row.get(key) for key in ("case", "route", "framework", "passed", "checks")}, "requests_attributed": attributed})
followups = []
for path in sorted((E / "live").glob("null-*.json")):
    row = read(path)
    if "passed" not in row:
        continue
    followups.append({"path": str(path.relative_to(E)), "framework": row["framework"], "passed": row["passed"], "checks": row.get("checks")})
tests = ET.parse(E / "final-all-junit.xml").getroot()
suites = list(tests) if tests.tag == "testsuites" else [tests]
counts = {key: sum(int(suite.get(key, 0)) for suite in suites) for key in ("tests", "failures", "errors", "skipped")}
notebook_rows = {}
for path in sorted((E / "notebook-runs").glob("*/results.json")):
    notebook_rows.update({row["path"]: row for row in read(path)})
notebooks = list(notebook_rows.values())
examples = read(E / "examples-offline.json")["rows"]
by_path = {row["path"]: row for row in examples}
for path in sorted(E.glob("examples-retry*/examples-selected.json")):
    by_path.update({row["path"]: row for row in read(path)["rows"]})
examples = list(by_path.values())
summary = {"installation": read(E / "installation.json"), "offline": {"tests": counts,
    "examples": len(examples), "examples_passed": sum(row.get("passed") is True for row in examples),
    "examples_separate_profile": [row["path"] for row in examples if row.get("passed") is None],
    "notebooks": len(notebooks), "notebooks_passed": sum(row["passed"] for row in notebooks),
    "notebook_skipped_cells": sum(len(row["skipped_cells"]) for row in notebooks)},
    "matrix": rows, "extras": extra_rows, "null_followups": followups,
    "budget": {"requests": len(ledger["attempts"]), "limits": ledger["limits"],
        "reserved_usd": str(sum(Decimal(item["reserved_usd"]) for item in ledger["attempts"])),
        "remaining_requests": ledger["limits"]["requests"] - len(ledger["attempts"]), "requests_by_phase": dict(phases)},
    "accounting_note": "Workers ran concurrently. Raw window deltas include other workers; attributed counts use the global ledger phase and per-worker window. Ledger total is authoritative.",
    "release_ready": False, "published": False, "blocker": "Exact Bedrock/Qwen required-nullable Tool arguments still omit amount; no defaults inserted."}
(E / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
manifest = {str(path.relative_to(ROOT)).replace("\\", "/"): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in E.rglob("*") if path.is_file() and path.name != "evidence-manifest.json" and "__pycache__" not in path.parts}
(E / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"offline": summary["offline"], "budget": summary["budget"], "compositions": [row for row in rows if row["case"] == "composition"]}, indent=2))
