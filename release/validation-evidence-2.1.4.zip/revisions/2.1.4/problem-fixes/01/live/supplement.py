"""Extra regression: explicit null and three framework actors in one System."""
import argparse
import importlib
import json
import os
from pathlib import Path
import sys
import time

from run import E, ROOT, read, write, serialize, secrets, ledger_summary, digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("null", "interop"))
    parser.add_argument("route")
    parser.add_argument("framework")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    plan = read(E / "plan.json")
    installed = read(ROOT / "revisions/2.1.4/problem-fixes/01/installation.json")
    assert digest(ROOT / installed["wheel"]) == plan["wheel_sha256"]
    sys.path[:0] = [installed["site"], str(ROOT)]
    spec = plan["routes"][args.route]
    values, _ = secrets()
    provider = "ollama-runtime" if args.route.startswith("ollama-") else args.route
    prefix = {"ollama-runtime": "OLLAMA", "openai-runtime": "OPENAI", "bedrock-runtime": "BEDROCK"}[provider]
    key = "ollama-local" if args.route == "ollama-local" else values[spec["key_env"]]
    os.environ.update(OPENAI_AGENTS_DISABLE_TRACING="1", OTEL_SDK_DISABLED="true", LANGSMITH_TRACING="false",
        AWS_EC2_METADATA_DISABLED="true", AGENTIC_BUDGET_FILE=str(E / "campaign-budget.json"))
    os.environ.update({prefix + "_BASE_URL": spec["endpoint"], prefix + "_MODEL": spec["model"], prefix + "_MODEL_ID": spec["model"]})
    if provider == "ollama-runtime":
        os.environ["OLLAMA_API_KEY"] = key
    if provider == "bedrock-runtime":
        os.environ.update(AWS_BEARER_TOKEN_BEDROCK=key, AWS_REGION=spec["region"], AWS_DEFAULT_REGION=spec["region"])
    import agentic_systems as toolkit
    from agentic_systems_studio.budget import ensure_budget
    budget = ensure_budget()
    budget.phase = "supplement/" + args.mode + "/" + args.route + "/" + args.framework
    connection = toolkit.runtime(provider=provider, model=spec["model"], endpoint=spec["endpoint"], api_key=key,
        region=spec.get("region"), timeout_s=90, max_tokens=1024, max_turns=3, max_tool_calls=1, max_retries=0)
    row = {"case": args.mode, "route": args.route, "framework": args.framework, "model": spec["model"],
           "wheel_sha256": plan["wheel_sha256"], "budget_before": ledger_summary(), "passed": False}
    started = time.monotonic()
    try:
        if args.mode == "null":
            module = importlib.import_module("examples.applications.data_quality.example")
            oracle = module.run().data
            actor = toolkit.Agent("explicit_null", runtime=connection, framework=toolkit.framework(args.framework),
                skills=(module.capability,), instructions="Call profile_rows exactly once with every supplied row unchanged. Each row MUST include both id and amount, including amount:null where given. Then return ONLY the Tool business result as a JSON object, without its transport envelope. Never infer defaults or omit null fields.",
                contract={"tool_expectation": {"all_of": ["profile_rows"]}, "completion": "always_finalize",
                          "output_schema": module.Output.model_json_schema()}, policy={"repair": False})
            result = actor.run(module.sample, timeout_s=180)
            events = [e for node in result.walk() for e in node.tool_events if e.name == "profile_rows"]
            arguments = [json.loads(json.dumps(e.input, default=lambda value: value.model_dump())) for e in events]
            checks = {"business_output": result.ok and result.data == oracle,
                      "explicit_null_preserved": bool(arguments) and all(value == module.sample for value in arguments),
                      "invariants": result.check_invariants().ok}
            row["input"] = module.sample
        else:
            module = importlib.import_module("examples.framework_interop.example")
            system = module.build({name: connection for name in plan["frameworks"]})
            result = system.compile().run({"value": 42, "trail": []}, timeout_s=360)
            oracle = {"value": 45, "trail": plan["frameworks"], "validated": True}
            checks = {"three_framework_business_output": result.ok and result.data == oracle,
                      "invariants": result.check_invariants().ok,
                      "roundtrip": toolkit.RunResult(**result.to_dict()).data == result.data}
        row.update(checks=checks, passed=all(checks.values()), result=serialize(result, toolkit),
                   human_results=result.human_results(), lineage=result.lineage().to_dict())
    except Exception as exc:
        row["error"] = {"type": type(exc).__name__, "message": str(exc)[-4000:]}
    row.update(elapsed_s=round(time.monotonic() - started, 3), budget_after_worker_snapshot=ledger_summary())
    write(args.output, row)
    return 0 if row["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
