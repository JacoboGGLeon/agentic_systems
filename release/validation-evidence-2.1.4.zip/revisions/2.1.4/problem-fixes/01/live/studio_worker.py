"""Metered Studio controller regression using the installed application wheel."""
import argparse
import json
import os
from pathlib import Path
import sys
from run import E, ROOT, read, write, secrets, ledger_summary, digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("framework")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    install = read(E.parent / "installation.json")
    plan = read(E / "plan.json")
    assert digest(ROOT / install["wheel"]) == plan["wheel_sha256"]
    sys.path.insert(0, install["site"])
    values, _ = secrets()
    spec = plan["routes"]["bedrock-runtime"]
    os.environ.update(OPENAI_AGENTS_DISABLE_TRACING="1", OTEL_SDK_DISABLED="true", LANGSMITH_TRACING="false",
        AWS_EC2_METADATA_DISABLED="true", AGENTIC_BUDGET_FILE=str(E / "campaign-budget.json"),
        AWS_BEARER_TOKEN_BEDROCK=values["AWS_BEARER_TOKEN_BEDROCK"], AWS_REGION=spec["region"],
        BEDROCK_MODEL_ID=spec["model"], BEDROCK_BASE_URL=spec["endpoint"])
    import agentic_systems as toolkit
    import agentic_systems_studio as studio_module
    from agentic_systems_studio import ConversationConfig, build_conversational_system
    from agentic_systems_studio.budget import ensure_budget
    assert Path(studio_module.__file__).is_relative_to(Path(install["site"]))
    budget = ensure_budget()
    budget.phase = "studio/bedrock/" + args.framework
    row = {"case": "studio", "route": "bedrock-runtime", "framework": args.framework,
           "model": spec["model"], "wheel_sha256": install["wheel_sha256"], "studio_sha256": install["studio_sha256"],
           "budget_before": ledger_summary(), "passed": False}
    try:
        studio = build_conversational_system(ConversationConfig(provider="bedrock-runtime", framework=args.framework,
            model=spec["model"], max_response_repairs=0, timeout_s=90))
        result = studio.run("Calcula 7 * 6. Responde únicamente con el resultado numérico.")
        events = [event for node in result.walk() for event in node.tool_events if event.name == "safe_calculate" and event.ok]
        checks = {"answer": result.ok and result.data["answer"].strip() == "42", "observed_calculation": len(events) == 1,
                  "invariants": result.check_invariants().ok, "roundtrip": toolkit.RunResult(**result.to_dict()).data == result.data}
        row.update(checks=checks, passed=all(checks.values()), result=result.to_dict(), human_results=result.human_results(), lineage=result.lineage().to_dict())
    except Exception as exc:
        row["error"] = {"type": type(exc).__name__, "message": str(exc)}
    row["budget_after_worker_snapshot"] = ledger_summary()
    write(args.output, row)
    return 0 if row["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
