"""Sequential supplementary acceptance; no retry or model substitution."""
import subprocess
import sys
from datetime import datetime, timezone
from run import E, ROOT, read, write, secrets, ledger_summary


destination = E / "extras" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
destination.mkdir(parents=True)
tasks = [("null", "bedrock-runtime", framework) for framework in ("native", "openai-agents", "strands")]
tasks += [("interop", route, "all") for route in read(E / "plan.json")["routes"]]
tasks += [("studio", "bedrock-runtime", framework) for framework in ("native", "openai-agents", "strands")]
rows = []
for case, route, framework in tasks:
    name = "--".join((case, route, framework))
    output = destination / (name + ".json")
    before = ledger_summary()
    if before["remaining_requests"] < 10:
        row = {"case": case, "route": route, "framework": framework, "passed": False, "not_attempted": True, "reason": "budget reserve"}
    else:
        command = [sys.executable, str(E / "studio_worker.py"), framework, str(output)] if case == "studio" else [sys.executable, str(E / "supplement.py"), case, route, framework, str(output)]
        process = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        log, _ = process.communicate()  # Process exit joins workers; hooks remain active.
        for secret in secrets()[1]:
            log = log.replace(secret, "[REDACTED]")
        (destination / (name + ".log")).write_text(log, encoding="utf-8")
        row = read(output) if output.exists() else {"case": case, "route": route, "framework": framework, "passed": False, "returncode": process.returncode}
        row.update(budget_after_process_exit=ledger_summary(), requests=ledger_summary()["attempts"] - before["attempts"])
    rows.append(row)
    write(destination / "results.json", {"rows": rows, "budget": ledger_summary(), "published": False})
    print({key: row.get(key) for key in ("case", "route", "framework", "passed", "requests")}, flush=True)
