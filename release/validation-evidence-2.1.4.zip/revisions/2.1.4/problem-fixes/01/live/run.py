"""Isolated, metered dev8 workers; every provider attempt shares one capped ledger."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

E = Path(__file__).resolve().parent
ROOT = E.parents[4]


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ledger_summary():
    from decimal import Decimal
    ledger = read(E / "campaign-budget.json")
    total = sum((Decimal(row["reserved_usd"]) for row in ledger["attempts"]), Decimal(0))
    return {"attempts": len(ledger["attempts"]), "reserved_usd": str(total),
            "inference_requests": sum(row.get("kind") != "metadata" for row in ledger["attempts"]),
            "remaining_requests": ledger["limits"]["requests"] - len(ledger["attempts"]),
            "remaining_usd": str(Decimal(str(ledger["limits"]["usd"])) - total)}


def secrets():
    from dotenv import dotenv_values
    values = dotenv_values(ROOT / ".env")
    return values, [values.get(key) for key in ("OPENAI_API_KEY", "OLLAMA_API_KEY", "AWS_BEARER_TOKEN_BEDROCK") if values.get(key)]


def write(path, data):
    text = json.dumps(data, ensure_ascii=False, indent=2)
    for secret in secrets()[1]:
        text = text.replace(secret, "[REDACTED]")
    path.write_text(text + "\n", encoding="utf-8")


def serialize(value, toolkit):
    if isinstance(value, toolkit.RunResult):
        return value.to_dict()
    if isinstance(value, dict):
        return {str(key): serialize(item, toolkit) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [serialize(item, toolkit) for item in value]
    return value


def worker(route, framework, case, destination):
    plan = read(E / "plan.json")
    install = read(ROOT / "revisions/2.1.4/problem-fixes/01/installation.json")
    assert digest(ROOT / install["wheel"]) == plan["wheel_sha256"]
    assert digest(E / "challenge.py") == plan["challenge_sha256"]
    sys.path[:0] = [install["site"], str(E)]
    values, _ = secrets()
    spec = plan["routes"][route]
    provider = "ollama-runtime" if route.startswith("ollama-") else route
    prefix = {"ollama-runtime": "OLLAMA", "openai-runtime": "OPENAI", "bedrock-runtime": "BEDROCK"}[provider]
    os.environ.update(OPENAI_AGENTS_DISABLE_TRACING="1", OTEL_SDK_DISABLED="true", LANGSMITH_TRACING="false",
                      AWS_EC2_METADATA_DISABLED="true", AGENTIC_BUDGET_FILE=str(E / "campaign-budget.json"))
    os.environ.update({prefix + "_BASE_URL": spec["endpoint"], prefix + "_MODEL": spec["model"], prefix + "_MODEL_ID": spec["model"]})
    key = "ollama-local" if route == "ollama-local" else values[spec["key_env"]]
    if provider == "ollama-runtime":
        os.environ["OLLAMA_API_KEY"] = key
    if provider == "bedrock-runtime":
        os.environ.update(AWS_BEARER_TOKEN_BEDROCK=key, AWS_REGION=spec["region"], AWS_DEFAULT_REGION=spec["region"])
    import agentic_systems as toolkit
    from agentic_systems_studio.budget import ensure_budget
    import challenge
    assert Path(toolkit.__file__).resolve().is_relative_to(Path(install["site"]))
    budget = ensure_budget()
    budget.phase = route + "/" + framework + "/" + case
    before = ledger_summary()
    row = {"route": route, "framework": framework, "case": case, "version": toolkit.__version__,
           "wheel_sha256": plan["wheel_sha256"], "model": spec["model"], "budget_before": before, "passed": False}
    started = time.monotonic()
    try:
        connection = toolkit.runtime(provider=provider, model=spec["model"], endpoint=spec["endpoint"], api_key=key,
            region=spec.get("region"), timeout_s=90, max_tokens=1024, max_turns=3,
            max_tool_calls=0 if case == "pilot" else 1, max_retries=0)
        evidence = getattr(challenge, case)(connection, framework)
        row["evidence"] = serialize(evidence, toolkit)
        row["passed"] = all(evidence["checks"].values())
        if case == "negatives":
            row["passed"] = row["passed"] and ledger_summary()["attempts"] == before["attempts"]
    except Exception as exc:
        row["error"] = {"type": type(exc).__name__, "message": str(exc)[-5000:]}
    row.update(elapsed_s=round(time.monotonic() - started, 3), budget_after_worker_snapshot=ledger_summary())
    write(destination, row)
    # Hooks intentionally remain until Python joins any surviving SDK workers.
    return 0 if row["passed"] else 1


def run_all():
    plan = read(E / "plan.json")
    run = E / "runs" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    run.mkdir(parents=True)
    rows = []
    blocked = {}
    for case in ("pilot", "negatives", "composition"):
        for route in plan["routes"]:
            for framework in plan["frameworks"]:
                name = case + "--" + route + "--" + framework
                output = run / (name + ".json")
                remaining = ledger_summary()["remaining_requests"]
                minimum = 24 if case == "composition" else 1 if case == "pilot" else 0
                if route in blocked or remaining < minimum:
                    row = {"case": case, "route": route, "framework": framework, "passed": False,
                           "not_attempted": True, "reason": blocked.get(route, "insufficient-budget-for-complete-case")}
                else:
                    command = [sys.executable, str(Path(__file__).resolve()), "--worker", "--route", route,
                               "--framework", framework, "--case", case, "--output", str(output)]
                    started = time.monotonic()
                    proc = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                            text=True, encoding="utf-8", errors="replace")
                    try:
                        log, _ = proc.communicate(timeout=1200)
                    except subprocess.TimeoutExpired:
                        proc.terminate()
                        log, _ = proc.communicate()
                        blocked[route] = "worker-timeout; preserve reservations and stop this route"
                    for secret in secrets()[1]:
                        log = log.replace(secret, "[REDACTED]")
                    (run / (name + ".log")).write_text(log, encoding="utf-8")
                    row = read(output) if output.exists() else {"case": case, "route": route, "framework": framework,
                            "passed": False, "error": {"type": "WorkerFailed", "returncode": proc.returncode}}
                    row.update(budget_after_process_exit=ledger_summary(), process_elapsed_s=round(time.monotonic() - started, 3))
                    if "budget_before" in row:
                        row["requests"] = row["budget_after_process_exit"]["attempts"] - row["budget_before"]["attempts"]
                    text = json.dumps(row).lower()
                    if any(term in text for term in ("bearer token has expired", "invalid api key", "invalid_api_key", "authenticationerror", "401 unauthorized")):
                        blocked[route] = "authentication-failed; remaining scenarios not attempted with this credential"
                rows.append(row)
                write(run / "results.json", {"plan": plan, "rows": rows, "budget": ledger_summary(), "published": False})
                print(json.dumps({key: row.get(key) for key in ("case", "route", "framework", "passed", "requests", "not_attempted")}), flush=True)
    return 0 if all(row["passed"] for row in rows) else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--route")
    parser.add_argument("--framework")
    parser.add_argument("--case", choices=("pilot", "negatives", "composition"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    raise SystemExit(worker(args.route, args.framework, args.case, args.output) if args.worker else run_all())
