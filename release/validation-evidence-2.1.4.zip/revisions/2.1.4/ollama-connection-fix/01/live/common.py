"""Pinned installation, redaction and persistent budget; no app composition."""
import hashlib
import json
import os
from pathlib import Path
import sys
from decimal import Decimal
from dotenv import dotenv_values

E = Path(__file__).resolve().parent
ROOT = E.parents[4]


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def budget_summary():
    ledger = read(E / "campaign-budget.json")
    total = sum((Decimal(row["reserved_usd"]) for row in ledger["attempts"]), Decimal(0))
    return {"requests": len(ledger["attempts"]), "reserved_usd": str(total),
            "remaining_requests": ledger["limits"]["requests"] - len(ledger["attempts"]),
            "remaining_usd": str(Decimal(str(ledger["limits"]["usd"])) - total)}


def secret_values():
    values = dotenv_values(ROOT / ".env")
    return values, [values[key] for key in ("OLLAMA_API_KEY", "OPENAI_API_KEY", "AWS_BEARER_TOKEN_BEDROCK") if values.get(key)]


def write(path, data):
    text = json.dumps(data, ensure_ascii=False, indent=2)
    for value in secret_values()[1]:
        text = text.replace(value, "[REDACTED]")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text + "\n", encoding="utf-8")


def prepare(phase):
    plan = read(E / "plan.json")
    install = plan["installation"]
    assert hashlib.sha256((ROOT / install["wheel"]).read_bytes()).hexdigest() == install["wheel_sha256"]
    sys.path[:0] = [install["site"], str(ROOT)]
    values, _ = secret_values()
    os.environ.update(OPENAI_AGENTS_DISABLE_TRACING="1", OTEL_SDK_DISABLED="true", LANGSMITH_TRACING="false",
                      AWS_EC2_METADATA_DISABLED="true", AGENTIC_BUDGET_FILE=str(E / "campaign-budget.json"),
                      OLLAMA_API_KEY=values["OLLAMA_API_KEY"], OLLAMA_BASE_URL=plan["routes"]["ollama-cloud"]["endpoint"])
    import agentic_systems as toolkit
    from agentic_systems_studio.budget import ensure_budget
    assert Path(toolkit.__file__).is_relative_to(Path(install["site"]))
    budget = ensure_budget()
    budget.phase = phase
    return toolkit, plan, values
