"""Run the explicit financial lesson against a pinned installed wheel."""
import argparse
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import sys
import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager
from dotenv import dotenv_values

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[5]
E = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("profile", choices=("python", "mixed"))
args = parser.parse_args()
install = json.loads((ROOT / "revisions/2.1.4/ollama-connection-fix/01/installation.json").read_text())
assert hashlib.sha256((ROOT / install["wheel"]).read_bytes()).hexdigest() == install["wheel_sha256"]
ledger_path = ROOT / "revisions/2.1.4/ollama-connection-fix/01/live/campaign-budget.json"
before = json.loads(ledger_path.read_text())
if args.profile == "mixed":
    assert before["limits"] == {"usd": 2, "requests": 70}
    assert len(before["attempts"]) + 40 <= 70, "Insufficient request reserve"
stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
destination = E / (stamp + "-" + args.profile)
destination.mkdir()
path = E / "financial-native-source.ipynb"
notebook = nbformat.reads(path.read_text(encoding="utf-8"), 4)
source_sha = hashlib.sha256("\n".join(c.source for c in notebook.cells if c.cell_type == "code").encode()).hexdigest()
bootstrap = "import sys, platform\nplatform.platform()\nfrom pathlib import Path\n"
bootstrap += "sys.path[:0]=" + repr([install["site"], str(ROOT), str(ROOT / "tutorials")]) + "\n"
bootstrap += "import agentic_systems as _sdk\nassert Path(_sdk.__file__).is_relative_to(Path(" + repr(install["site"]) + "))\n"
bootstrap += "profile=" + repr(args.profile) + "\n"
if args.profile == "python":
    bootstrap += "from _offline import enforce_offline, blocked_attempts\nenforce_offline()\n"
else:
    bootstrap += "from agentic_systems_studio.budget import ensure_budget\n_budget=ensure_budget()\n_budget.phase='ollama-connection-fix/notebook'\n"
capture = destination / "evidence.json"
footer = "Path(" + repr(str(capture)) + ").write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')\n"
if args.profile == "python":
    footer += "assert blocked_attempts()==0\n"
notebook.cells = [nbformat.v4.new_code_cell(bootstrap), *notebook.cells, nbformat.v4.new_code_cell(footer)]
env = {**os.environ, "PYTHONPATH": os.pathsep.join([install["site"], str(ROOT)]),
       "OPENAI_AGENTS_DISABLE_TRACING": "1", "OTEL_SDK_DISABLED": "true", "LANGSMITH_TRACING": "false",
       "AWS_EC2_METADATA_DISABLED": "true"}
values = dotenv_values(ROOT / ".env")
secrets = [values.get(key) for key in ("OPENAI_API_KEY", "OLLAMA_API_KEY", "AWS_BEARER_TOKEN_BEDROCK") if values.get(key)]
if args.profile == "mixed":
    env.update({key: values[key] for key in ("OPENAI_API_KEY", "OLLAMA_API_KEY", "AWS_BEARER_TOKEN_BEDROCK")})
    env.update(AGENTIC_BUDGET_FILE=str(ledger_path), OPENAI_BASE_URL="https://api.openai.com/v1",
               BEDROCK_BASE_URL="https://bedrock-runtime.us-east-2.amazonaws.com", AWS_REGION="us-east-2",
               AWS_DEFAULT_REGION="us-east-2", OLLAMA_BASE_URL="https://ollama.com/v1")
km = KernelManager(kernel_name="python3")
km.kernel_spec.argv = [sys.executable, "-m", "ipykernel_launcher", "-f", "{connection_file}"]
client = NotebookClient(notebook, km=km, timeout=1200, resources={"metadata": {"path": str(ROOT)}})
error = None
try:
    client.execute(env=env)
except Exception as exc:
    error = {"type": type(exc).__name__, "message": str(exc)[-6000:]}
finally:
    if client.kc is not None:
        client.kc.stop_channels()
    if km.has_kernel:
        km.shutdown_kernel(now=False)
notebook.cells = notebook.cells[1:-1]
notebook.metadata["validation"] = {"profile": args.profile, "wheel_sha256": install["wheel_sha256"], "passed": error is None}
serialized = nbformat.writes(notebook)
for secret in secrets:
    assert secret not in serialized, "Credential in notebook output"
nbformat.write(notebook, destination / "executed.ipynb")
if error is None:
    visible = destination / "python-visible.ipynb" if args.profile == "python" else ROOT / "examples/financial_mixed/03_financial_system_native_local.executed.ipynb"
    nbformat.write(notebook, visible)
after = json.loads(ledger_path.read_text())
row = {"profile": args.profile, "passed": error is None, "error": error, "wheel_sha256": install["wheel_sha256"],
       "source_sha256": source_sha, "requests_before": len(before["attempts"]), "requests_after": len(after["attempts"]),
       "requests": len(after["attempts"]) - len(before["attempts"]),
       "reserved_usd_total": str(sum(Decimal(x["reserved_usd"]) for x in after["attempts"])),
       "reserved_usd_this_run": str(sum(Decimal(x["reserved_usd"]) for x in after["attempts"][len(before["attempts"]):]))}
text = json.dumps(row, ensure_ascii=False, indent=2)
for secret in secrets:
    text = text.replace(secret, "[REDACTED]")
(destination / "result.json").write_text(text, encoding="utf-8")
print(text)
raise SystemExit(0 if error is None else 1)
