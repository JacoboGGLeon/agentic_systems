"""Validate the completed campaign and seal new evidence without rewriting history."""
import hashlib
import json
import nbformat
from common import E, ROOT, read, write, budget_summary, secret_values


rows = read(E / "results.json")["rows"]
assert len(rows) == 5 and all(row["passed"] for row in rows)
plan = read(E / "frozen-plan.json")
for name, digest in plan["worker_sha256"].items():
    assert hashlib.sha256((E / name).read_bytes()).hexdigest() == digest
for path, digest in read(E / "historical-ledgers.json").items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest
pair = {name: read(E / ("results/" + name + ".json")) for name in ("pilots", "sync", "async")}
for name in ("sync", "async"):
    assert len(pair[name]["attempts"]) == 2
    assert all(attempt["passed"] and all(attempt["checks"].values()) for attempt in pair[name]["attempts"])
notebooks = {}
for path in sorted(E.glob("*/result.json")):
    row = read(path)
    assert row["passed"], row
    assert row["source_sha256"] == plan["notebook_code_sha256"]
    notebooks[row["profile"]] = {"validation": row, "evidence": read(path.parent / "evidence.json")}
assert set(notebooks) == {"python", "mixed"}


def business(evidence):
    single, episodes, evaluated = evidence["run_results"]
    assert all(result["ok"] for result in (single, episodes, evaluated))
    return {"single": single["data"], "episodes": episodes["data"]["outputs"],
            "environment_state": episodes["data"]["summary"]["state"],
            "eval": {key: evaluated["data"][key] for key in ("total", "passed", "failed")}}


assert business(notebooks["python"]["evidence"]) == business(notebooks["mixed"]["evidence"])


def walk(node):
    yield node
    for child in node.get("children", []):
        yield from walk(child)


for mode in ("sync", "async"):
    for attempt in pair[mode]["attempts"]:
        actors = {(node.get("engine"), node.get("model"), node.get("meta", {}).get("framework_adapter"))
                  for node in walk(attempt["result"])}
        for route in ("ollama-local", "ollama-cloud"):
            assert ("ollama-runtime", plan["routes"][route]["model"], "native") in actors


observed = sorted({(node.get("engine"), node.get("model"), node.get("meta", {}).get("framework_adapter"))
                   for result in notebooks["mixed"]["evidence"]["run_results"] for node in walk(result)
                   if node.get("model") and node.get("meta", {}).get("framework_adapter")}, key=str)
assert ("ollama-runtime", plan["routes"]["ollama-local"]["model"], "native") in observed
assert {row[2] for row in observed} == {"native", "strands", "openai-agents"}
ledger = read(E / "campaign-budget.json")
assert len(ledger["attempts"]) <= 70
summary = {"passed": True, "budget": budget_summary(), "profiles": rows,
           "observed_notebook_actors": observed, "business_equal_python_mixed": True,
           "business": business(notebooks["mixed"]["evidence"]),
           "historical_ledgers_unchanged": True, "published": False,
           "wheel_sha256": plan["installation"]["wheel_sha256"],
           "scope": "Specific connection regression plus original financial application, not full release acceptance"}
write(E / "summary.json", summary)
secrets = secret_values()[1]
for path in E.rglob("*"):
    if path.is_file() and path.suffix != ".pyc":
        assert not any(secret in path.read_text(encoding="utf-8", errors="replace") for secret in secrets), path
nb = nbformat.reads((ROOT / "examples/financial_mixed/03_financial_system_native_local.executed.ipynb").read_text(encoding="utf-8"), 4)
assert nb.metadata["validation"]["passed"]
for secret in secrets:
    assert secret not in nbformat.writes(nb)
files = [path for path in E.rglob("*") if path.is_file() and path.name != "manifest.json" and path.suffix != ".pyc"]
files.append(ROOT / "examples/financial_mixed/03_financial_system_native_local.executed.ipynb")
write(E / "manifest.json", {str(path.relative_to(ROOT)).replace("\\", "/"): hashlib.sha256(path.read_bytes()).hexdigest() for path in files})
print(json.dumps({"budget": summary["budget"], "observed": observed, "all_passed": True}))
