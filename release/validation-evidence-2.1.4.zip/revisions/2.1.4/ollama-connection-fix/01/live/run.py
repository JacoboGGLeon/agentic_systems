"""Sequential workers; caps remain active until process/kernel exit."""
import subprocess
import sys
import hashlib
from common import E, ROOT, read, write, budget_summary, secret_values


plan = read(E / "plan.json")
plan["worker_sha256"] = {name: hashlib.sha256((E / name).read_bytes()).hexdigest()
                         for name in ("common.py", "pair_worker.py", "notebook_worker.py", "run.py")}
assert not (E / "frozen-plan.json").exists(), "Preserve previous campaign run; do not rerun automatically"
write(E / "frozen-plan.json", plan)
rows = []
for profile in ("pilots", "sync", "async", "notebook_python", "notebook_mixed"):
    if profile.startswith("notebook"):
        command = [sys.executable, str(E / "notebook_worker.py"), "python" if profile.endswith("python") else "mixed"]
    else:
        command = [sys.executable, str(E / "pair_worker.py"), profile]
    before = budget_summary()
    process = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, encoding="utf-8", errors="replace")
    log, _ = process.communicate()  # Kernel/SDK hooks outlive inference threads.
    for secret in secret_values()[1]:
        log = log.replace(secret, "[REDACTED]")
    (E / (profile + ".log")).write_text(log, encoding="utf-8")
    after = budget_summary()
    row = {"profile": profile, "passed": process.returncode == 0, "returncode": process.returncode,
           "before": before, "after_process_exit": after, "requests": after["requests"] - before["requests"]}
    rows.append(row)
    write(E / "results.json", {"rows": rows, "budget": after, "published": False})
    print(row, flush=True)
    if process.returncode:
        break  # Do not repeat or change framework/model to turn failures green.
