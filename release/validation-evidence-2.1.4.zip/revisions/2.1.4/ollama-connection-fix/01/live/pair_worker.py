"""Real local/cloud native actors, Tool evidence, sync and public arun."""
import argparse
import asyncio
import os
from common import E, prepare, write, budget_summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("pilots", "sync", "async"))
    args = parser.parse_args()
    toolkit, plan, keys = prepare("ollama-connection-fix/" + args.mode)
    import pydantic
    before = budget_summary()
    report = {"mode": args.mode, "wheel_sha256": plan["installation"]["wheel_sha256"],
              "budget_before": before, "passed": False, "attempts": []}

    def runtime(route):
        spec = plan["routes"][route]
        return toolkit.runtime(provider="ollama-runtime", model=spec["model"], endpoint=spec["endpoint"],
            api_key="ollama-local" if route == "ollama-local" else keys["OLLAMA_API_KEY"],
            timeout_s=90, max_retries=0, max_turns=3, max_tool_calls=1, max_tokens=512)

    try:
        if args.mode == "pilots":
            for route in ("ollama-local", "ollama-cloud"):
                actor = toolkit.Agent("readiness", runtime=runtime(route),
                    instructions='Return exactly the JSON object {"ready":true}. No other text.',
                    contract={"output_schema": {"type": "object", "properties": {"ready": {"const": True}},
                                                "required": ["ready"], "additionalProperties": False}}, policy={"repair": False})
                result = actor.run("Confirm readiness.", timeout_s=120)
                passed = result.ok and result.data == {"ready": True} and not any(n.tool_events for n in result.walk())
                report["attempts"].append({"route": route, "passed": passed, "result": result.to_dict(),
                                           "human_results": result.human_results(), "lineage": result.lineage().to_dict()})
                write(E / "results/pilots.json", report)
                if not passed:
                    raise AssertionError("Pilot failed: " + route)
        else:
            @toolkit.tool
            def local_receipt(value: int) -> dict:
                """Return exact local business evidence, never a model guess."""
                return {"local": value}

            @toolkit.tool
            def cloud_receipt(value: int) -> dict:
                """Return exact cloud business evidence, never a model guess."""
                return {"cloud": value}

            def contract(name, field):
                return {"tool_expectation": {"all_of": [name], "allowed": [name], "min_count": 1},
                        "completion": "always_finalize", "failure_policy": "no_unresolved",
                        "output_schema": {"type": "object", "properties": {field: {"type": "integer"}},
                                          "required": [field], "additionalProperties": False}}

            local = toolkit.Agent("local", runtime=runtime("ollama-local"),
                skills=(toolkit.skill(name="local", tools=(local_receipt,)),),
                instructions="Call local_receipt exactly once with the supplied value unchanged. Return ONLY the Tool business JSON without its transport envelope.",
                contract=contract("local_receipt", "local"), policy={"repair": False})
            cloud = toolkit.Agent("cloud", runtime=runtime("ollama-cloud"),
                skills=(toolkit.skill(name="cloud", tools=(cloud_receipt,)),),
                instructions="Call cloud_receipt exactly once with the supplied value unchanged. Return ONLY the Tool business JSON without its transport envelope.",
                contract=contract("cloud_receipt", "cloud"), policy={"repair": False})

            class State(pydantic.BaseModel):
                value: int
                local: int | None = None
                cloud: int | None = None

            def local_step(state):
                return local.run({"value": state.value})

            def cloud_step(state):
                return cloud.run({"value": state.value})

            async def local_async(state):
                return await local.arun({"value": state.value})

            async def cloud_async(state):
                return await cloud.arun({"value": state.value})

            graph = toolkit.Graph(State)
            graph.add_node("local", local_async if args.mode == "async" else local_step)
            graph.add_node("cloud", cloud_async if args.mode == "async" else cloud_step)
            graph.add_edge(toolkit.START, "local")
            graph.add_edge("local", "cloud")
            graph.add_edge("cloud", toolkit.END)
            program = toolkit.System("two_native_ollamas", graph=graph).compile()
            environment = (os.environ["OLLAMA_BASE_URL"], os.environ["OLLAMA_API_KEY"])
            for value in (7, 11):
                result = asyncio.run(program.arun({"value": value}, timeout_s=360)) if args.mode == "async" else program.run({"value": value}, timeout_s=360)
                events = [event for node in result.walk() for event in node.tool_events]
                checks = {"business": result.ok and result.data == {"value": value, "local": value, "cloud": value},
                          "observed_tools": len(events) == 2 and all(e.ok and e.input == {"value": value} for e in events),
                          "invariants": result.check_invariants().ok,
                          "serialization": toolkit.RunResult(**result.to_dict()).data == result.data,
                          "environment_unchanged": environment == (os.environ["OLLAMA_BASE_URL"], os.environ["OLLAMA_API_KEY"])}
                passed = all(checks.values())
                report["attempts"].append({"input": {"value": value}, "passed": passed, "checks": checks,
                    "result": result.to_dict(), "human_results": result.human_results(), "lineage": result.lineage().to_dict()})
                write(E / ("results/" + args.mode + ".json"), report)
                if not passed:
                    raise AssertionError("Native pair failed; retain attempt and stop this profile")
        report["passed"] = True
    except Exception as exc:
        report["error"] = {"type": type(exc).__name__, "message": str(exc)}
    report["budget_after_worker_snapshot"] = budget_summary()
    write(E / ("results/" + args.mode + ".json"), report)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
