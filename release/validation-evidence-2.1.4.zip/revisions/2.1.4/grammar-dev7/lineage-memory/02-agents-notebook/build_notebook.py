"""Write the lesson with visible declarations, never an imported example runner."""

import json
from pathlib import Path

import nbformat


ROOT = Path(__file__).resolve().parents[4]
source = (ROOT / "examples/lineage_memory/example.py").read_text(encoding="utf-8")


def between(start, end):
    return source.split(start, 1)[1].split(end, 1)[0].strip()


md = nbformat.v4.new_markdown_cell
code = nbformat.v4.new_code_cell
cells = [
    md("""# Lineage y Memory que cambian decisiones · 2.1.4.dev7

**Input → proceso → output:** el pago PAY-001 llega con 5000 centavos MXN;
un Agent calcula una comisión de 50 y otro verifica su evidencia y decide.
El primer run aprueba. El segundo recibe exactamente el mismo input y lo manda
a revisión por duplicado gracias al episodio conservado en Memory.

Todo es Python determinista, coordinado por LangGraph: sin modelos, claves ni
inferencia. Requiere el SDK local **2.1.4.dev7** y sus dependencias; no se instala
nada desde el notebook. Ejecuta las celdas en orden desde un kernel limpio.

| Canal | Contenido | Papel en la decisión |
|---|---|---|
| State | payment_id, amount, fee, decision | Datos del pago actual |
| Context.data / sources | Política y su referencia | Comisión y límite |
| Context.lineage | Evidencia del Agent precedente | Exigir y verificar el cálculo |
| Context.episodes | Ejecución anterior con linaje compacto | Detectar aprobación anterior del mismo pago |

Las capturas de Context se guardan aparte para inspección; nunca se devuelven
como estado del Graph. Su linaje es evidencia observada, no pensamiento privado."""),
    code('import pydantic\nimport agentic_systems as toolkit\n\nassert toolkit.__version__ == "2.1.4.dev7"\nprint("SDK:", toolkit.__version__)'),
    md("""## 1. Estado pequeño y Tools explícitas

`strict=True` rechaza coerciones de tipos y `extra="forbid"` rechaza campos
inesperados. Los campos opcionales son resultados todavía no calculados.
El revisor no acepta una comisión solo porque esté en el estado: necesita el
linaje exitoso de fees y exige consistencia con la política actual.
Después consulta evidencia estructurada de aprobaciones anteriores en Memory."""),
    code("class Payment" + between("class Payment", "# Observation only:")),
    code("# Capturas de observación: no forman parte del estado.\nreceived_contexts = []\n\n" + "@toolkit.tool\n" + between("@toolkit.tool", "fee_graph =")),
    md("""## 2. Un Graph por Agent y un Graph para el System

fees organiza el cálculo; reviewer organiza la decisión. El System los conecta
en ese orden. No hay lectura manual de una traza global ni historial añadido
al modelo Payment: el contexto se entrega al ejecutar cada Tool."""),
    code("fee_graph =" + between("fee_graph =", "memory =")),
    md("""## 3. Política y Memory compartida desde el System

Memory conserva hasta dos episodios locales. En cada entrada se obtiene una vista
de los episodios previos que heredan los Agents. Al terminar, el System recuerda
su resultado. `compile()` prepara el harness sin ejecutar Tools ni escribir memoria."""),
    code("memory =" + between("memory =", "first =")),
    md("""## 4. Primera ejecución: hay evidencia actual, todavía no hay historia

fees recibe lineage y episodes vacíos. reviewer recibe la evidencia actual de
fees, pero ningún episodio anterior: PAY-001 puede aprobarse."""),
    code('payment = {"payment_id": "PAY-001", "amount": 5000}\nfirst = harness.run(payment)\nassert first.ok\nassert first.data == {**payment, "fee": 50, "decision": "approve"}\nfirst_contexts = list(received_contexts)\nassert len(first_contexts) == 2\nassert len(memory.read()) == 1\nprint(first.human_results())'),
    md("### Context exacto recibido en la primera ejecución\n\nSe muestra el objeto completo: política, fuentes, linaje actual y episodios."),
    code('import json\n\nfor row in first_contexts:\n    print("Agent:", row["agent"])\n    print(json.dumps(row["context"], ensure_ascii=False, indent=2))'),
    md("""## 5. Segunda ejecución: el mismo input cambia de decisión por Memory

Se reutiliza el harness y su Memory. La comisión y el límite siguen iguales.
reviewer encuentra en el linaje del episodio anterior que PAY-001 ya fue aprobado
y devuelve review_duplicate. La ejecución termina correctamente: pedir revisión
es una decisión de negocio, no un fallo del runtime."""),
    code('second = harness.run(payment)\nassert second.ok\nassert second.data == {**payment, "fee": 50, "decision": "review_duplicate"}\nsecond_contexts = list(received_contexts[2:])\nassert len(second_contexts) == 2\nassert len(memory.read()) == 2\nprint(second.human_results())'),
    md("""### Context exacto recibido en la segunda ejecución

Ambos reciben el episodio de first en episodes. Solo reviewer recibe además la
observación actual de fees en lineage. El primer agente no confunde historia de
la ejecución anterior con trabajo ya realizado en esta ejecución."""),
    code('for row in second_contexts:\n    print("Agent:", row["agent"])\n    print(json.dumps(row["context"], ensure_ascii=False, indent=2))'),
    md("""## 6. Controles que demuestran la dependencia causal

1. Mismo input y mismo Graph sin Memory: vuelve a approve.
2. fee=50 en el estado, sin linaje previo de fees: la ejecución falla.
3. fees registra fee=51: el linaje existe, pero contradice la política; falla.

Los controles usan Systems independientes y no escriben la Memory del ejemplo."""),
    code('''without_memory = toolkit.System(
    "payments", payment_graph, context=system.context,
).run(payment)
assert without_memory.ok and without_memory.data["decision"] == "approve"
print("Sin Memory:")
print(without_memory.human_results())

missing_lineage = toolkit.System(
    "missing_evidence", review_graph, context=system.context,
).run({**payment, "fee": 50})
assert not missing_lineage.ok
assert "Missing successful fees lineage" in str(missing_lineage.errors)
print("\\nSin linaje previo:")
print(missing_lineage.human_results())'''),
    code('''def incorrect_fee(state):
    return {"fee": 51}


bad_graph = toolkit.Graph(Payment)
bad_graph.add_node("fees", incorrect_fee)
bad_graph.add_node("reviewer", reviewer)
bad_graph.add_edge(toolkit.START, "fees")
bad_graph.add_edge("fees", "reviewer")
bad_graph.add_edge("reviewer", toolkit.END)

inconsistent_lineage = toolkit.System(
    "inconsistent_evidence", bad_graph, context=system.context,
).run(payment)
assert not inconsistent_lineage.ok
assert "Fee is inconsistent" in str(inconsistent_lineage.errors)
assert len(memory.read()) == 2
print(inconsistent_lineage.human_results())'''),
    md("## 7. Resumen verificado: cuatro Context, cuatro campos de negocio"),
    code('''main_contexts = first_contexts + second_contexts
assert len(main_contexts) == 4
print("Run | Agent    | lineage actual | episodios previos")
for index, row in enumerate(main_contexts):
    context = row["context"]
    assert context["data"] == {"currency": "MXN", "fee_bps": 100, "ceiling": 10000}
    assert context["sources"] == ["payment-policy-v1"]
    assert len(context["episodes"]) == index // 2
    if row["agent"] == "fees":
        assert context["lineage"] == []
    else:
        assert any(item["name"] == "fees" and item["ok"] for item in context["lineage"])
    if index >= 2:
        assert context["episodes"][0]["execution_id"] == first.execution_id
    print(index // 2 + 1, row["agent"], len(context["lineage"]), len(context["episodes"]), sep=" | ")

assert set(first.data) == set(second.data) == {"payment_id", "amount", "fee", "decision"}
print("\\nPrimer resultado:", first.data)
print("Segundo resultado:", second.data)
print("Campos de estado:", list(Payment.model_fields))
print("Episodios conservados:", len(memory.read()))
print("Dos ejecuciones y tres controles: correctos.")'''),
    md("""## Alcance y límites

El linaje de un Agent o System puede aportar contexto a otro. Context también
puede incluir política y fuentes externas: mostrar solo lineage es una proyección,
no el Context completo. Aquí inspeccionamos todo, pero las decisiones consultan
campos estructurados; no analizan el texto de human_results.

Memory es local, acotada y contiene resúmenes. La ausencia de una aprobación en
esos episodios **no prueba** que nunca ocurrió. Esta demostración no sustituye
un registro persistente de idempotencia ni evita duplicados concurrentes.
Los cuatro campos de negocio no contienen Context, episodios ni árboles de
RunResult; internamente el grafo usa referencias acotadas a evidencia.

La validación cubre este escenario determinista y sus controles. No certifica
proveedores externos ni nuevas versiones. No se publica ningún artefacto.

[Programa equivalente](example.py) · [Explicación y evidencia](README.md)"""),
]
installation = json.loads((Path(__file__).resolve().parent.parent / "installation.json").read_text())
notebook = nbformat.v4.new_notebook(cells=cells, metadata={
    "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
    "language_info": {"name": "python"},
    "agentic_systems": {"version": "2.1.4.dev7", "profile": "offline", "wheel_sha256": installation["wheel_sha256"]},
})
target = ROOT / "examples/lineage_memory/01_lineage_memory_decisions.ipynb"
nbformat.validate(notebook)
for cell in notebook.cells:
    if cell.cell_type == "code":
        compile(cell.source, "<notebook-cell>", "exec")
nbformat.write(notebook, target)
print(target)
