"""Two Agents, two executions: business state stays separate from Context."""

import pydantic
import agentic_systems as toolkit


class Payment(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(strict=True, extra="forbid")
    amount: int = pydantic.Field(gt=0)
    fee: int | None = None
    decision: str | None = None


# Observation only: these snapshots never become graph state or instructions.
received_contexts = []


@toolkit.tool
def calculate_fee(amount: int, *, context: toolkit.Context) -> dict:
    received_contexts.append({"agent": "fees", "context": context.to_dict()})
    return {"fee": amount * context.data["fee_bps"] // 10000}


@toolkit.tool
def decide(amount: int, fee: int, *, context: toolkit.Context) -> dict:
    received_contexts.append({"agent": "reviewer", "context": context.to_dict()})
    return {
        "decision": "approve" if amount + fee <= context.data["ceiling"] else "review"
    }


fee_graph = toolkit.Graph(Payment)
fee_graph.add_node("calculate_fee", calculate_fee)
fee_graph.add_edge(toolkit.START, "calculate_fee")
fee_graph.add_edge("calculate_fee", toolkit.END)
fee_agent = toolkit.Agent("fees", fee_graph)

review_graph = toolkit.Graph(Payment)
review_graph.add_node("decide", decide)
review_graph.add_edge(toolkit.START, "decide")
review_graph.add_edge("decide", toolkit.END)
reviewer = toolkit.Agent("reviewer", review_graph)

payment_graph = toolkit.Graph(Payment)
payment_graph.add_node("fees", fee_agent)
payment_graph.add_node("reviewer", reviewer)
payment_graph.add_edge(toolkit.START, "fees")
payment_graph.add_edge("fees", "reviewer")
payment_graph.add_edge("reviewer", toolkit.END)

memory = toolkit.Memory(capacity=2)
system = toolkit.System(
    "payments",
    payment_graph,
    context=toolkit.Context(
        {"currency": "MXN", "fee_bps": 100, "ceiling": 10000},
        sources=("payment-policy-v1",),
    ),
    memory=memory,
)

harness = system.compile()
assert received_contexts == [] and memory.read() == []

first = harness.run({"amount": 5000})
second = harness.run({"amount": 12000})
assert first.ok and second.ok
assert first.data == {"amount": 5000, "fee": 50, "decision": "approve"}
assert second.data == {"amount": 12000, "fee": 120, "decision": "review"}

assert len(received_contexts) == 4
for index, row in enumerate(received_contexts):
    context = row["context"]
    assert context["data"] == {"currency": "MXN", "fee_bps": 100, "ceiling": 10000}
    assert context["sources"] == ["payment-policy-v1"]
    assert len(context["episodes"]) == index // 2
    if row["agent"] == "fees":
        assert context["lineage"] == []
    else:
        assert any(item["name"] == "fees" for item in context["lineage"])
    if index >= 2:
        assert context["episodes"][0]["execution_id"] == first.execution_id
        assert "lineage" in context["episodes"][0]

assert len(memory.read()) == 2
assert set(first.data) == set(second.data) == {"amount", "fee", "decision"}

if __name__ == "__main__":
    for result in (first, second):
        print(result.human_results())
