"""Offline evidence runner; executes the visible example against the sealed wheel."""

import hashlib
import json
from pathlib import Path
import runpy
import sys

root = Path(__file__).resolve().parents[4]
destination = Path(__file__).resolve().parent
installation = json.loads((destination.parent / "installation.json").read_text())
sys.path.insert(0, installation["site"])
sys.path.insert(1, str(root / "tutorials"))
from _offline import enforce_offline, blocked_attempts

enforce_offline()
import agentic_systems as toolkit

assert toolkit.__version__ == "2.1.4.dev7"
assert Path(toolkit.__file__).is_relative_to(Path(installation["site"]))
wheel = root / installation["wheel"]
assert hashlib.sha256(wheel.read_bytes()).hexdigest() == installation["wheel_sha256"]
namespace = runpy.run_path(str(root / "examples/lineage_memory/example.py"), run_name="__main__")
results = [namespace["first"], namespace["second"]]
contexts = namespace["received_contexts"]
evidence = {
    "version": toolkit.__version__,
    "installed_module": toolkit.__file__,
    "wheel_sha256": installation["wheel_sha256"],
    "offline": True,
    "blocked_external_attempts": blocked_attempts(),
    "inference_calls": 0,
    "received_contexts": contexts,
    "results": [result.to_dict() for result in results],
    "human_results": [result.human_results() for result in results],
    "memory": namespace["memory"].read(),
}
assert evidence["blocked_external_attempts"] == 0
(destination / "evidence.json").write_text(json.dumps(evidence, indent=2, ensure_ascii=False), encoding="utf-8")
lines = [
    "# Lineage y Memory entre agentes y ejecuciones · 2.1.4.dev7",
    "",
    "Ejecutado offline contra el wheel instalado fuera del checkout. Cero inferencia y cero intentos externos.",
    "",
    "Input → System → Agent fees calcula comisión → Agent reviewer aplica política → Output.",
    "Memory se adjunta al System: cada ejecución completa produce un episodio; los agentes heredan esa vista.",
    "La decisión depende de la política y los datos actuales. Este ejemplo demuestra entrega del contexto histórico, no aprendizaje ni cambios de política.",
    "",
    "El estado público contiene únicamente amount, fee y decision. Context y episodios se observan aparte; el estado interno conserva referencias acotadas a evidencia.",
    "",
    "| Ejecución | Agente | Observaciones previas actuales | Episodios anteriores |",
    "|---|---|---|---|",
]
for index, row in enumerate(contexts):
    context = row["context"]
    lines.append(f"| {index // 2 + 1} | {row['agent']} | {len(context['lineage'])} | {len(context['episodes'])} |")
for index, result in enumerate(results):
    lines += ["", f"## Ejecución {index + 1}", "", "```text", result.human_results(), "```"]
    for row in contexts[index * 2:index * 2 + 2]:
        lines += ["", f"### Context exacto recibido por {row['agent']}", "", "```json", json.dumps(row["context"], indent=2, ensure_ascii=False), "```"]
lines += [
    "", "## Verificaciones", "",
    "- compile no ejecutó Tools ni escribió Memory.",
    "- Los dos agentes recibieron la política y su fuente.",
    "- reviewer recibió el linaje de fees en ambas ejecuciones.",
    "- En la primera ejecución ninguno recibió episodios anteriores.",
    "- En la segunda ambos recibieron exactamente el episodio de la primera.",
    "- El primer agente de la segunda ejecución no confundió el linaje anterior con el linaje actual.",
    "- Memory terminó con dos episodios; los resultados conservaron solo tres campos de negocio.",
    "", "Memoria local en proceso, sin persistencia ni búsqueda semántica. Linaje observado, no razonamiento privado del modelo.",
    "", f"Wheel SHA-256: `{installation['wheel_sha256']}`.",
]
(destination / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("Verified: 2 executions, 4 Context snapshots, 2 remembered episodes, 0 inference calls.")
