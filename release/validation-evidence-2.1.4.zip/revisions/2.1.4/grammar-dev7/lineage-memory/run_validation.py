"""Offline evidence runner; executes the visible example against the sealed wheel."""

import hashlib
import json
from pathlib import Path
import runpy
import sys

root = Path(__file__).resolve().parents[4]
destination = Path(__file__).resolve().parent
installation = json.loads((destination.parent / "installation.json").read_text())
sys.path.insert(0, installation["site"])
sys.path.insert(1, str(root / "tutorials"))
from _offline import enforce_offline, blocked_attempts  # noqa: E402 -- resolved after local harness path

enforce_offline()
import agentic_systems as toolkit  # noqa: E402 -- sealed installation, offline guard already active

assert toolkit.__version__ == "2.1.4.dev7"
assert Path(toolkit.__file__).is_relative_to(Path(installation["site"]))
wheel = root / installation["wheel"]
assert hashlib.sha256(wheel.read_bytes()).hexdigest() == installation["wheel_sha256"]
namespace = runpy.run_path(str(root / "examples/lineage_memory/example.py"), run_name="__main__")
results = [namespace["first"], namespace["second"]]
contexts = list(namespace["received_contexts"])

# Counterfactual: identical business input with no remembered episode approves.
without_memory = toolkit.System(
    "payments", namespace["payment_graph"], context=namespace["system"].context,
).run({"payment_id": "PAY-001", "amount": 5000})
assert without_memory.ok and without_memory.data["decision"] == "approve"

# Negative controls: valid business fields alone cannot replace current evidence.
missing_lineage = toolkit.System(
    "missing_evidence", namespace["review_graph"], context=namespace["system"].context,
).run({"payment_id": "PAY-001", "amount": 5000, "fee": 50})
assert not missing_lineage.ok and "Missing successful fees lineage" in str(missing_lineage.errors)


def incorrect_fee(state):
    return {"fee": 51}


bad_graph = toolkit.Graph(namespace["Payment"])
bad_graph.add_node("fees", incorrect_fee)
bad_graph.add_node("reviewer", namespace["reviewer"])
bad_graph.add_edge(toolkit.START, "fees")
bad_graph.add_edge("fees", "reviewer")
bad_graph.add_edge("reviewer", toolkit.END)
inconsistent_lineage = toolkit.System(
    "inconsistent_evidence", bad_graph, context=namespace["system"].context,
).run({"payment_id": "PAY-001", "amount": 5000})
assert not inconsistent_lineage.ok and "Fee is inconsistent" in str(inconsistent_lineage.errors)
assert len(namespace["memory"].read()) == 2
evidence = {
    "version": toolkit.__version__,
    "installed_module": toolkit.__file__,
    "wheel_sha256": installation["wheel_sha256"],
    "offline": True,
    "blocked_external_attempts": blocked_attempts(),
    "inference_calls": 0,
    "received_contexts": contexts,
    "results": [result.to_dict() for result in results],
    "human_results": [result.human_results() for result in results],
    "memory": namespace["memory"].read(),
    "controls": {
        "same_input_without_memory": without_memory.to_dict(),
        "missing_lineage": missing_lineage.to_dict(),
        "inconsistent_lineage": inconsistent_lineage.to_dict(),
    },
}
assert evidence["blocked_external_attempts"] == 0
(destination / "evidence.json").write_text(json.dumps(evidence, indent=2, ensure_ascii=False), encoding="utf-8")
lines = [
    "# Lineage y Memory entre agentes y ejecuciones · 2.1.4.dev7",
    "",
    "Ejecutado offline contra el wheel instalado fuera del checkout. Cero inferencia y cero intentos externos.",
    "",
    "Input → System → Agent fees calcula comisión → Agent reviewer aplica política → Output.",
    "Memory se adjunta al System: cada ejecución completa produce un episodio; los agentes heredan esa vista.",
    "El revisor exige evidencia actual de fees consistente con la política. Después consulta el linaje estructurado de los episodios: si PAY-001 ya fue aprobado, devuelve review_duplicate.",
    "El mismo input pasa de approve a review_duplicate exclusivamente por Memory. Sin Memory vuelve a approve; sin linaje actual o con fee inconsistente, la ejecución falla.",
    "",
    "El estado público contiene únicamente payment_id, amount, fee y decision. Context y episodios se observan aparte; el estado interno conserva referencias acotadas a evidencia.",
    "",
    "| Ejecución | Agente | Observaciones previas actuales | Episodios anteriores |",
    "|---|---|---|---|",
]
for index, row in enumerate(contexts):
    context = row["context"]
    lines.append(f"| {index // 2 + 1} | {row['agent']} | {len(context['lineage'])} | {len(context['episodes'])} |")
for index, result in enumerate(results):
    lines += ["", f"## Ejecución {index + 1}", "", "```text", result.human_results(), "```"]
    for row in contexts[index * 2:index * 2 + 2]:
        lines += ["", f"### Context exacto recibido por {row['agent']}", "", "```json", json.dumps(row["context"], indent=2, ensure_ascii=False), "```"]
lines += [
    "", "## Verificaciones", "",
    "- compile no ejecutó Tools ni escribió Memory.",
    "- Los dos agentes recibieron la política y su fuente.",
    "- reviewer recibió el linaje de fees en ambas ejecuciones.",
    "- En la primera ejecución ninguno recibió episodios anteriores.",
    "- En la segunda ambos recibieron exactamente el episodio de la primera.",
    "- El primer agente de la segunda ejecución no confundió el linaje anterior con el linaje actual.",
    "- Memory terminó con dos episodios; los resultados conservaron solo cuatro campos de negocio.",
    "- Mismo pago sin Memory: approve; con Memory del primer run: review_duplicate.",
    "- Sin evidencia actual de fees: error Missing successful fees lineage.",
    "- Fee incorrecto aunque registrado en el linaje: error Fee is inconsistent with lineage or current policy.",
    "", "## Context frente a linaje", "",
    "Context incluye data y sources del dominio, lineage del trabajo actual y episodes históricos. El linaje de un Agent o System puede alimentar Context, pero no sustituye necesariamente la política ni las fuentes externas.",
    "", "## Alcance de la política de duplicados", "",
    "Demostración acotada: consulta solo los episodios locales retenidos y los pasos disponibles en su resumen. Un episodio ausente o truncado no demuestra que el pago nunca existió. No sustituye un registro persistente de idempotencia ni garantiza exclusión de duplicados concurrentes.",
    "", "Memoria local en proceso, sin persistencia ni búsqueda semántica. Linaje observado, no razonamiento privado del modelo.",
    "", f"Wheel SHA-256: `{installation['wheel_sha256']}`.",
]
(destination / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("Verified: 2 executions, 4 main Context snapshots, 3 causal controls, 2 remembered episodes, 0 inference calls.")
