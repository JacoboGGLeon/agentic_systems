"""Bind the example review to final source bytes and reconcile notebook inventory."""

import ast
import hashlib
import json
from pathlib import Path

import nbformat


ROOT = Path(__file__).resolve().parents[4]
DEST = Path(__file__).resolve().parent
installation = json.loads((DEST.parent / "installation.json").read_text())
entrypoints = json.loads((DEST / "03/examples-offline.json").read_text(encoding="utf-8"))
assert entrypoints["offline_guard_blocked_attempts"] == 0
assert entrypoints["inference_requests"] == 0
for row in entrypoints["rows"]:
    if row.get("passed") is True:
        assert hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() == row["source_sha256"], row["path"]
    else:
        assert row["status"] == "separate-local-protocol-profile"

latest = {}
for result_file in sorted(DEST.glob("0*/notebook-runs/*/results.json")):
    for row in json.loads(result_file.read_text(encoding="utf-8")):
        previous = latest.get(row["path"])
        if previous is None or result_file.parent.name > previous[0].parent.name:
            latest[row["path"]] = (result_file, row)

inventory_path = ROOT / "docs/NOTEBOOK_INVENTORY_214.json"
inventory = json.loads(inventory_path.read_text(encoding="utf-8"))
notebooks = {row["path"]: row for row in inventory["notebooks"]}
core = set(inventory["core_observed"])
notebook_rows = []
for path, (result_file, row) in sorted(latest.items()):
    notebook = nbformat.read(ROOT / path, 4)
    nbformat.validate(notebook)
    source = "\n".join(c.source for c in notebook.cells if c.cell_type == "code")
    digest = hashlib.sha256(source.encode()).hexdigest()
    assert digest == row["code_sha256_before_parameterization"] and row["passed"], path
    assert not any(output.output_type == "error" for c in notebook.cells if c.cell_type == "code" for output in c.outputs)
    evidence_root = result_file.parents[2]
    capture_path = evidence_root / row["capture"]
    capture = json.loads(capture_path.read_text(encoding="utf-8"))
    words = set(capture["grammar"]["combined"]["used"])
    calls = []
    for node in ast.walk(ast.parse(source)):
        if isinstance(node, ast.Call):
            calls.append({"call": ast.unparse(node.func), "line": node.lineno,
                          "positional_arguments": len(node.args),
                          "keywords": [key.arg or "**kwargs" for key in node.keywords]})
    notebooks[path] = {
        "path": path, "offline_passed": True, "source_code_sha256": digest,
        "core_words_observed": sorted(words & core),
        "upstream_words_observed": sorted(words - core),
        "calls_and_parameters_declared": sorted(calls, key=lambda call: call["line"]),
        "skipped_cells": row["skipped_cells"],
        "capture": capture_path.relative_to(ROOT).as_posix(), "hidden_builders": [],
    }
    notebook_rows.append({**row, "capture": capture_path.relative_to(ROOT).as_posix(),
                          "notebook_sha256": hashlib.sha256((ROOT / path).read_bytes()).hexdigest()})
inventory["notebooks"] = [notebooks[key] for key in sorted(notebooks)]
inventory_path.write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

summary = {
    "version": "2.1.4.dev7", "wheel_sha256": installation["wheel_sha256"],
    "entrypoints_passed": sum(row.get("passed") is True for row in entrypoints["rows"]),
    "separate_profiles_not_repeated": [row["path"] for row in entrypoints["rows"] if row.get("passed") is None],
    "notebooks": notebook_rows, "notebooks_passed": len(notebook_rows),
    "inference_calls": 0, "blocked_external_attempts": 0,
    "scope": "Examples only; offline profile. No live provider or full Studio UI acceptance.",
}
(DEST / "SUMMARY.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

catalog_path = ROOT / "examples/catalog.json"
catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
catalog_backup = DEST / "before/examples/catalog.json"
catalog_backup.parent.mkdir(parents=True, exist_ok=True)
if not catalog_backup.exists():
    catalog_backup.write_bytes(catalog_path.read_bytes())
by_path = {row["path"]: row for row in entrypoints["rows"] if row.get("passed") is True}
catalog["reviewed_at"] = "2026-10-29"
for entry in catalog["entries"]:
    validation = entry.get("validation", {})
    row = by_path.get(validation.get("entrypoint"))
    if row:
        validation.update({"source_sha256": row["source_sha256"],
                           "report": "revisions/2.1.4/grammar-dev7/examples-review/REPORT.md",
                           "scope": "Offline entrypoint; live providers and full Studio UI not certified."})
    if entry.get("next_action", "").startswith("Importar run"):
        entry["next_action"] = "Leer las declaraciones visibles y ejecutar el ejemplo con sus aserciones; consultar la evidencia del archivo."
catalog["entries"] = [entry for entry in catalog["entries"] if entry["id"] != "lineage_memory"]
catalog["entries"].append({
    "id": "lineage_memory", "title": "Lineage y Memory que cambian decisiones",
    "group": "patterns", "purpose": "Evidencia entre Agents, memoria entre episodios y aislamiento de Eval.",
    "flow": "PAY-001 approve → mismo pago review_duplicate; Environment comparte progreso y Eval lo aísla por caso.",
    "readiness": "offline-passed", "api_version": "2.1.4.dev7",
    "implementation": "Tools, Graph, Agents, System, Context, Memory, Environment y Eval visibles en el notebook.",
    "sources": [{"label": "Notebook ejecutado", "target": "examples/lineage_memory/01_lineage_memory_decisions.ipynb"},
                {"label": "Programa base de dos Agents", "target": "examples/lineage_memory/example.py"}],
    "validation": {"version": "2.1.4.dev7", "status": "offline-passed",
                   "entrypoint": "examples/lineage_memory/example.py",
                   "source_sha256": by_path["examples/lineage_memory/example.py"]["source_sha256"],
                   "wheel_sha256": installation["wheel_sha256"],
                   "report": "revisions/2.1.4/grammar-dev7/examples-review/SUMMARY.json",
                   "scope": "18 notebook code cells; no skipped cells; offline, zero inference."},
    "next_action": "Abrir el notebook y recorrer las dos ejecuciones, controles, episodios y casos aislados.",
})
catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
lineage_row = next(row for row in notebook_rows if "/lineage_memory/" in row["path"])
(DEST.parent / "lineage-memory/notebook-validation/SUMMARY.json").write_text(
    json.dumps({"passed": True, "version": summary["version"], "wheel_sha256": summary["wheel_sha256"],
                **lineage_row}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

lines = ["# Examples: evidencia offline por archivo · 2.1.4.dev7", "",
         f"{summary['entrypoints_passed']} entrypoints correctos y {summary['notebooks_passed']} notebooks con perfil offline correcto. Cada hash de código coincide con la evidencia. Cero inferencia.",
         "", "MCP/A2A no se repitió: requiere su perfil local separado. Studio conserva una celda local omitida. No se validaron proveedores online ni todos los controles UI.",
         "", "## Entrypoints", "", "| Archivo | Estado |", "|---|---|"]
for row in entrypoints["rows"]:
    lines.append(f"| {row['path']} | {row['status']} |")
lines += ["", "## Notebooks", "", "| Archivo | Celdas ejecutadas | Omitidas |", "|---|---:|---:|"]
for row in notebook_rows:
    lines.append(f"| {row['path']} | {row['executed_code_cells']} | {len(row['skipped_cells'])} |")
lines += ["", "## Alcance de la revisión estática", "",
          "inventory.json enumera cada .py, .md e .ipynb activo, su hash, atributos públicos, importaciones entre ejemplos y errores de sintaxis. Excluye history/evidence/build/dist/cachés. Los archivos de infraestructura y tests de Studio se inspeccionan estáticamente; eso no implica ejecutarlos todos.",
          "", "before/ conserva los textos previos a las correcciones editoriales. Las pasadas 01/02/03 permanecen separadas. El código del SDK y el wheel no se modificaron."]
(DEST / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(json.dumps({key: summary[key] for key in ("entrypoints_passed", "notebooks_passed", "inference_calls")}, indent=2))
