# Comprobar un juez optimista · 2.1.4.dev7

Combinar expectativas exactas y un juez fixture.

```python
from examples.patterns.judge_calibration.example import run
report = run()
```

Input → proceso → output: Respuestas VALID y WRONG → juez que siempre aprueba + expectativas → [True, False]; no es calibración empírica de un modelo.

[Declaración](example.py) · [Evidencia](../../../revisions/2.1.4/pydantic-dev4/examples/examples--patterns--judge_calibration--example.py.json)

Perfil actual: **offline-passed**. El catálogo [de validación](../../../docs/LEARNING_VALIDATION_214.md) separa configuración, Python, servicios locales y pruebas de modelos. La evidencia 2.1.3 conservada es histórica y no certifica estos bytes.

[Validación histórica dev5 de Pydantic y human_results](../../../revisions/2.1.4/contracts-dev5/REPORT.md). La evidencia dev3 enlazada corresponde a la revisión anterior.
