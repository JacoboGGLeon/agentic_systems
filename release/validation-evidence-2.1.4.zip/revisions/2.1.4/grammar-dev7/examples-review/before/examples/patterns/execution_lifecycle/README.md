# Execution Lifecycle — API 2.1.4.dev7 · 2.1.4.dev7

Direct/compiled and async execution, shared action limits and controlled exhaustion.

Consulta [la implementación mantenida](../../execution_lifecycle/example.py). Esta carpeta es una referencia de navegación, no una segunda API ni una ejecución independiente.

[Estado real y límites](../../../docs/LEARNING_VALIDATION_214.md). La evidencia 2.1.3 es histórica.

[Validación histórica dev5 de Pydantic y human_results](../../../revisions/2.1.4/contracts-dev5/REPORT.md). La evidencia dev3 enlazada corresponde a la revisión anterior.
