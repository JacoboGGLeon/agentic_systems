"""Inventory all current example sources and reconcile teaching documentation."""

import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

import nbformat


ROOT = Path(__file__).resolve().parents[4]
DEST = Path(__file__).resolve().parent
EXCLUDED = {"history", "evidence", "__pycache__", ".ipynb_checkpoints", "node_modules", "build", "dist", ".pytest_cache"}
files = sorted(p for p in (ROOT / "examples").rglob("*") if p.is_file()
               and p.suffix in {".py", ".md", ".ipynb"}
               and not EXCLUDED.intersection(p.relative_to(ROOT).parts))
changed = []
validation = sorted(p.parent for p in DEST.glob("0*/examples-offline.json"))[-1]
for path in files:
    relative = path.relative_to(ROOT).as_posix()
    text = path.read_text(encoding="utf-8")
    updated = text
    if path.name == "README.md":
        updated = re.sub(
            r"```python\nfrom examples\.[\s\S]*?```",
            "La composición y las aserciones están visibles en [el código](example.py).\n"
            "Lee las declaraciones de Tools, Agents y Graph antes de ejecutar el ejemplo.",
            updated,
        ) if (path.parent / "example.py").exists() else updated
        updated = updated.replace("La evidencia dev3 enlazada corresponde a la revisión anterior.",
                                  "Las revisiones previas se conservan como evidencia histórica.")
        # Relink only concrete fresh evidence, never transfer an old acceptance.
        filename = relative.rsplit("/", 1)[0] + "/example.py"
        evidence = validation / "examples" / (filename.replace("/", "--") + ".json")
        if evidence.exists():
            row = json.loads(evidence.read_text(encoding="utf-8"))
            if row.get("passed") is True:
                updated = re.sub(r"revisions/2\.1\.4/(?:pydantic-dev4|grammar-dev7/examples-review/0[123])/examples/([^)]*\.json)",
                                 "revisions/2.1.4/grammar-dev7/examples-review/" + validation.name + r"/examples/\1", updated)
        updated = updated.replace("deterministic replay and native/LangGraph", "deterministic replay; LangGraph orchestration")
        updated = updated.replace("Instala el wheel dev6", "Instala el wheel local 2.1.4.dev7")
        updated = updated.replace("grafos StateGraph explícitos", "grafos toolkit.Graph explícitos")
    if path.suffix == ".py" and "/agentic_systems_studio/src/" not in relative:
        updated = updated.replace('"""Agentic Systems 2.1.4.dev4;', '"""Agentic Systems 2.1.4.dev7;')
    if updated != text:
        before = DEST / "before" / path.relative_to(ROOT)
        before.parent.mkdir(parents=True, exist_ok=True)
        if not before.exists():
            before.write_text(text, encoding="utf-8")
        path.write_text(updated, encoding="utf-8")
        changed.append(relative)

rows = []
removed = {"StateGraph", "check", "Limits", "Runtime", "Sequence", "Parallel", "Action"}
for path in files:
    relative = path.relative_to(ROOT).as_posix()
    text = path.read_text(encoding="utf-8")
    if path.suffix == ".ipynb":
        notebook = nbformat.read(path, 4)
        sources = [c.source for c in notebook.cells if c.cell_type == "code"]
    elif path.suffix == ".py":
        sources = [text]
    else:
        sources = []
    attributes, hidden, syntax = set(), [], []
    for source in sources:
        try:
            tree = ast.parse(source)
        except SyntaxError as exc:
            syntax.append(str(exc))
            continue
        aliases = {a.asname or a.name for n in ast.walk(tree) if isinstance(n, ast.Import)
                   for a in n.names if a.name == "agentic_systems"}
        for node in ast.walk(tree):
            if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id in aliases:
                attributes.add(node.attr)
            if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith("examples."):
                hidden.append(node.module)
    rows.append({
        "path": relative, "kind": path.suffix,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "toolkit_attributes": sorted(attributes), "removed_public_attributes": sorted(attributes & removed),
        "imports_other_examples": sorted(set(hidden)), "syntax_errors": syntax,
        "role": "studio-infrastructure-or-tests" if "/agentic_systems_studio/" in relative and ("/src/" in relative or "/tests/" in relative)
                else "test" if "/tests/" in relative else "launcher" if relative == "examples/order_fulfillment/run.py" else "teaching",
    })
report = {"counts": dict(Counter(row["kind"] for row in rows)), "files": rows, "changed": changed,
          "preserved_originals": sorted(p.relative_to(DEST / "before").as_posix() for p in (DEST / "before").rglob("*") if p.is_file())}
(DEST / "inventory.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"counts": report["counts"], "changed_files": len(changed),
                  "removed_api": [r["path"] for r in rows if r["removed_public_attributes"]],
                  "cross_imports": [{"path": r["path"], "role": r["role"], "imports": r["imports_other_examples"]}
                                    for r in rows if r["imports_other_examples"]],
                  "syntax_errors": [r["path"] for r in rows if r["syntax_errors"]]}, ensure_ascii=False, indent=2))
