"""One construction check for Tools, Skills and executable declarations."""
from functools import wraps
import inspect


def check(value):
    """Validate a component without running it, returning the same component.

    Also decorates sync/async factories returning a component. To check a
    Python Tool declaration, place @check above @tool. It is not an execution
    wrapper, a model judge, or certification of runtime/business correctness.
    """
    from ._tools import _Tool, _Skill
    from ._grammar import Agent, System, Environment, Eval

    if isinstance(value, (_Tool, _Skill)):
        value._to_engine().check().raise_if_failed()
        return value
    if isinstance(value, (Agent, System, Environment, Eval)):
        value.compile()
        return value
    if inspect.isfunction(value) or inspect.ismethod(value):
        annotation = inspect.signature(value).return_annotation
        if annotation in (dict, list, str, int, float, bool, type(None)):
            raise TypeError("check decorates component factories; declare operations with @tool")
        if inspect.iscoroutinefunction(value):
            @wraps(value)
            async def checked_factory(*args, **kwargs):
                return check(await value(*args, **kwargs))
        else:
            @wraps(value)
            def checked_factory(*args, **kwargs):
                return check(value(*args, **kwargs))
        return checked_factory
    raise TypeError("check expects a Tool, Skill, Agent, System, Environment, Eval or their factory")