Local 2.1.3 development bundle, not published.
Install the SDK wheel and its dependencies, then the Studio wheel with its ui extra.
Optional framework dependencies are not vendored. Offline installation needs a prepared wheelhouse.
Python mode is deterministic and needs no credentials. External inference requires an explicitly authorized ledger.
See studio/README.md. vLLM, IAM and enterprise delivery remain pending.
