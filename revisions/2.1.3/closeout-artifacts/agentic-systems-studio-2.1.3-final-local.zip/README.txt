Local validation bundle, not published. Install SDK and Studio wheels plus required optional dependencies.
Dependencies are not vendored; an offline installation needs a prepared wheelhouse.
No credentials are included. Python is deterministic; external inference requires explicit budget authorization.
